#!/usr/bin/env bash
set -euo pipefail
BASE_SHA=34d8b731370b42f84fb50c34ecd6ca41b39f0d08
TARGET_BRANCH=codex/owner-open-r15-runtime-hardening-20260831
PATCH_GZ="$1"
PATCH=/tmp/r15.patch
EXPECTED=/tmp/r15.expected
export TRILLIONNIUM_P01_CONFORMANCE_BUILD_VARIANT=userdebug
cat > "$EXPECTED" <<'EOF'
.github/workflows/owner-open-r15-runtime-hardening.yml
apps/trillionnium-owner-open-host/src/bin/r5_control_host_v6/entry.rs
apps/trillionnium-owner-open-host/src/bin/r5_control_host_v7/entry.rs
crates/trillionnium-owner-open-job-runtime/src/manager.rs
crates/trillionnium-owner-open-job-runtime/src/process.rs
crates/trillionnium-owner-open-job-runtime/src/types.rs
crates/trillionnium-owner-open-job-runtime/tests/runtime.rs
crates/trillionnium-owner-open-provider-jsonl/src/lib.rs
crates/trillionnium-owner-open-runtime/src/process.rs
crates/trillionnium-owner-open-runtime/src/types.rs
docs/protocols/owner-open-jobs-v1.md
tools/tests/test_owner_open_r15_runtime_hardening.py
tools/verify-owner-open-r5-workflow-boundaries.py
EOF
test "$(git rev-parse HEAD^1)" = "$BASE_SHA"
gzip -dc "$PATCH_GZ" > "$PATCH"
git reset --hard "$BASE_SHA"
git apply --index --whitespace=error "$PATCH"
git diff --cached --check
git diff --cached --name-only | LC_ALL=C sort > /tmp/r15.actual
diff -u "$EXPECTED" /tmp/r15.actual
python3 -m compileall -q tools
python3 -m unittest discover -s tools/tests -p 'test_*.py' -v
python3 tools/verify-owner-open-r5-workflow-boundaries.py --json
cargo fmt --all -- --check
cargo test --workspace --all-targets --locked
cargo clippy --workspace --all-targets --locked -- -D warnings
cargo doc --workspace --no-deps --locked
cargo test -p trillionnium-agent-direct-tools --all-targets --no-default-features --features dev-overrides --locked
cargo test -p trillionnium-agent-direct-tools --all-targets --no-default-features --features development-compatibility-lane --locked
cargo test -p trillionnium-agent-direct-tools --all-targets --no-default-features --features production-durable-hotpath --locked
cargo test -p trillionnium-agent-direct-tools --all-targets --no-default-features --features device-launch-package-conformance --locked
cargo test -p trillionnium-tool-runtime --all-targets --all-features --locked
cargo test -p trillionnium-shell-exec --all-targets --all-features --locked
cargo test -p trillionnium-agent-privilege-broker --all-targets --features p0-launch-package-device-conformance --locked
cargo test -p trillionnium-os-types --all-targets --all-features --locked
cargo test -p trillionnium-privilege-broker-protocol --all-targets --all-features --locked
cargo test -p trillionniumd --all-targets --no-default-features --features dev-conformance-fault-hook,legacy-plan-conformance --locked
git diff --exit-code "$BASE_SHA" -- Cargo.lock
git config user.name github-actions[bot]
git config user.email 41898282+github-actions[bot]@users.noreply.github.com
git commit -m 'fix(r15): fail closed and harden runtime boundaries'
test "$(git rev-parse HEAD^1)" = "$BASE_SHA"
test -z "$(git status --porcelain=v1 --untracked-files=all)"
git diff --name-only "$BASE_SHA" HEAD | LC_ALL=C sort > /tmp/r15.final
diff -u "$EXPECTED" /tmp/r15.final
if git ls-remote --exit-code --heads origin "refs/heads/$TARGET_BRANCH" >/dev/null 2>&1; then
  echo "target branch already exists" >&2
  exit 1
fi
git push origin "HEAD:refs/heads/$TARGET_BRANCH"
