#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] if Path(__file__).resolve().parent.name == "ops" else Path.cwd()
GENERATOR = ROOT / "tools/contracts/generate_module_contracts.py"
TESTS = ROOT / "tools/tests/test_module_contracts.py"


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected one match, observed {count}")
    return text.replace(old, new, 1)


def patch_generator() -> None:
    text = GENERATOR.read_text(encoding="utf-8")

    text = replace_once(
        text,
        "import math\nimport os\n",
        "import math\nimport os\nimport unicodedata\n",
        "generator import unicodedata",
    )

    text = replace_once(
        text,
        '''def reject_nonfinite(value: str) -> None:\n    raise ContractError(f"non-finite JSON number: {value}")\n\n\ndef strict_load(raw: bytes, label: str) -> Any:\n    require(len(raw) <= 4 * 1024 * 1024, f"{label} exceeds byte bound")\n    try:\n        value = json.loads(raw.decode("utf-8"), object_pairs_hook=strict_pairs, parse_constant=reject_nonfinite)\n    except (UnicodeError, json.JSONDecodeError, ContractError) as error:\n        raise ContractError(f"{label} is not strict JSON: {error}") from error\n    require(depth(value) <= 32, f"{label} exceeds depth bound")\n    return value\n''',
        '''def reject_nonfinite(value: str) -> None:\n    raise ContractError(f"non-finite JSON number: {value}")\n\n\ndef parse_finite_float(value: str) -> float:\n    parsed = float(value)\n    require(math.isfinite(parsed), f"non-finite JSON number: {value}")\n    return parsed\n\n\ndef strict_load(raw: bytes, label: str) -> Any:\n    require(len(raw) <= 4 * 1024 * 1024, f"{label} exceeds byte bound")\n    try:\n        value = json.loads(\n            raw.decode("utf-8"),\n            object_pairs_hook=strict_pairs,\n            parse_constant=reject_nonfinite,\n            parse_float=parse_finite_float,\n        )\n    except (UnicodeError, json.JSONDecodeError, ContractError) as error:\n        raise ContractError(f"{label} is not strict JSON: {error}") from error\n    require(depth(value) <= 32, f"{label} exceeds depth bound")\n    return value\n''',
        "generator finite float parser",
    )

    text = replace_once(
        text,
        '''    direct("schema").update({"type": "string", "const": label})\n    direct("module_id").update({"type": "string", "const": module})\n    direct("operation_id").update({"type": "string", "minLength": 1, "maxLength": 256})\n    direct("request_digest").update({"type": "string", "pattern": "^[0-9a-f]{64}$"})\n    if kind in {"api", "state"}:\n        direct("fencing_token").update({"type": "string", "minLength": 1, "maxLength": 512})\n        properties["payload"] = {"type": "object", "maxProperties": 64}\n    if kind == "api":\n        direct("ordering_key").update({"type": "string", "minLength": 1, "maxLength": 512})\n    elif kind == "errors":\n        direct("code").update({"type": "string", "minLength": 1, "maxLength": 128})\n        direct("original_cause").update({"type": "string", "minLength": 1, "maxLength": 4096})\n''',
        '''    def bounded_text(field: str, maximum_utf8_bytes: int) -> None:\n        direct(field).update(\n            {\n                "type": "string",\n                "minLength": 1,\n                "maxLength": maximum_utf8_bytes,\n                "pattern": r"^[^\\u0000-\\u001f\\u007f-\\u009f]+$",\n                "x-trillionnium-max-utf8-bytes": maximum_utf8_bytes,\n            }\n        )\n\n    direct("schema").update({"type": "string", "const": label})\n    direct("module_id").update({"type": "string", "const": module})\n    bounded_text("operation_id", 256)\n    direct("request_digest").update({"type": "string", "pattern": "^[0-9a-f]{64}$"})\n    if kind in {"api", "state"}:\n        bounded_text("fencing_token", 512)\n        properties["payload"] = {"type": "object", "maxProperties": 64}\n    if kind == "api":\n        bounded_text("ordering_key", 512)\n    elif kind == "errors":\n        bounded_text("code", 128)\n        bounded_text("original_cause", 4096)\n''',
        "schema bounded text constraints",
    )

    text = replace_once(
        text,
        '''        if "maxLength" in schema:\n            require(len(instance) <= schema["maxLength"], f"{path} too long")\n        if "pattern" in schema:\n            require(re.fullmatch(schema["pattern"], instance) is not None, f"{path} pattern differs")\n''',
        '''        if "maxLength" in schema:\n            require(len(instance) <= schema["maxLength"], f"{path} too long")\n        if "x-trillionnium-max-utf8-bytes" in schema:\n            maximum = schema["x-trillionnium-max-utf8-bytes"]\n            require(\n                isinstance(maximum, int)\n                and not isinstance(maximum, bool)\n                and maximum > 0\n                and len(instance.encode("utf-8")) <= maximum,\n                f"{path} exceeds UTF-8 byte bound",\n            )\n        if "pattern" in schema:\n            require(re.fullmatch(schema["pattern"], instance) is not None, f"{path} pattern differs")\n''',
        "schema utf8 extension enforcement",
    )

    text = replace_once(
        text,
        '''def validate_semantics(value: Any, kind: str, module_id_value: str, label: str) -> None:\n    require(isinstance(value, dict), "contract vector must be an object")\n    require(value.get("module_id") == module_id_value and value.get("schema") == label, "contract vector identity differs")\n    operation = value.get("operation_id")\n    require(isinstance(operation, str) and operation and len(operation.encode("utf-8")) <= 256 and not any(ord(char) < 32 or ord(char) == 127 for char in operation), "operation identity differs")\n    require(isinstance(value.get("request_digest"), str) and SHA64.fullmatch(value["request_digest"]) is not None, "request digest differs")\n    if kind in {"api", "state"}:\n        for field in ("host_epoch", "writer_epoch"):\n            require(isinstance(value.get(field), int) and not isinstance(value[field], bool) and 0 <= value[field] <= (1 << 64) - 1, f"{field} differs")\n        require(isinstance(value.get("fencing_token"), str) and value["fencing_token"], "fencing token differs")\n        require(isinstance(value.get("payload"), dict) and len(value["payload"]) <= 64, "payload differs")\n    if kind == "api":\n        require(isinstance(value.get("ordering_key"), str) and value["ordering_key"], "ordering key differs")\n    elif kind == "state":\n        require(value.get("state") in EXPECTED_LIFECYCLE_STATES | {"STATELESS"}, "state differs")\n        for field in ("durable_sequence", "monotonic_ns"):\n            require(isinstance(value.get(field), int) and not isinstance(value[field], bool) and 0 <= value[field] <= (1 << 64) - 1, f"{field} differs")\n    else:\n        require(value.get("class") in {"REJECTED_BEFORE_EFFECT","TRANSIENT_BEFORE_EFFECT","EFFECT_UNCERTAIN","TERMINAL_FAILURE","INTERNAL_INVARIANT"}, "error class differs")\n        require(value.get("retry_disposition") in {"MAY_RETRY_BEFORE_EFFECT","RECONCILE_REQUIRED_NO_AUTOMATIC_REDISPATCH","DO_NOT_RETRY"}, "retry disposition differs")\n        require(isinstance(value.get("effect_uncertain"), bool), "effect uncertainty type differs")\n        uncertain = value.get("class") == "EFFECT_UNCERTAIN"\n        reconcile = value.get("retry_disposition") == "RECONCILE_REQUIRED_NO_AUTOMATIC_REDISPATCH"\n        require(value.get("effect_uncertain") is uncertain and reconcile is uncertain, "error uncertainty semantics differ")\n''',
        '''def valid_text(value: Any, maximum_utf8_bytes: int) -> bool:\n    return (\n        isinstance(value, str)\n        and bool(value)\n        and len(value.encode("utf-8")) <= maximum_utf8_bytes\n        and not any(unicodedata.category(char) == "Cc" for char in value)\n    )\n\n\ndef validate_semantics(value: Any, kind: str, module_id_value: str, label: str) -> None:\n    require(isinstance(value, dict), "contract vector must be an object")\n    require(value.get("module_id") == module_id_value and value.get("schema") == label, "contract vector identity differs")\n    require(valid_text(value.get("operation_id"), 256), "operation identity differs")\n    require(isinstance(value.get("request_digest"), str) and SHA64.fullmatch(value["request_digest"]) is not None, "request digest differs")\n    if kind in {"api", "state"}:\n        for field in ("host_epoch", "writer_epoch"):\n            require(isinstance(value.get(field), int) and not isinstance(value[field], bool) and 0 <= value[field] <= (1 << 64) - 1, f"{field} differs")\n        require(valid_text(value.get("fencing_token"), 512), "fencing token differs")\n        require(isinstance(value.get("payload"), dict) and len(value["payload"]) <= 64, "payload differs")\n    if kind == "api":\n        require(valid_text(value.get("ordering_key"), 512), "ordering key differs")\n    elif kind == "state":\n        require(value.get("state") in EXPECTED_LIFECYCLE_STATES | {"STATELESS"}, "state differs")\n        for field in ("durable_sequence", "monotonic_ns"):\n            require(isinstance(value.get(field), int) and not isinstance(value[field], bool) and 0 <= value[field] <= (1 << 64) - 1, f"{field} differs")\n    else:\n        require(valid_text(value.get("code"), 128), "error code differs")\n        require(valid_text(value.get("original_cause"), 4096), "error cause differs")\n        require(value.get("class") in {"REJECTED_BEFORE_EFFECT","TRANSIENT_BEFORE_EFFECT","EFFECT_UNCERTAIN","TERMINAL_FAILURE","INTERNAL_INVARIANT"}, "error class differs")\n        require(value.get("retry_disposition") in {"MAY_RETRY_BEFORE_EFFECT","RECONCILE_REQUIRED_NO_AUTOMATIC_REDISPATCH","DO_NOT_RETRY"}, "retry disposition differs")\n        require(isinstance(value.get("effect_uncertain"), bool), "effect uncertainty type differs")\n        uncertain = value.get("class") == "EFFECT_UNCERTAIN"\n        reconcile = value.get("retry_disposition") == "RECONCILE_REQUIRED_NO_AUTOMATIC_REDISPATCH"\n        require(value.get("effect_uncertain") is uncertain and reconcile is uncertain, "error uncertainty semantics differ")\n''',
        "generator semantic text parity",
    )

    # Android build-host consumer: finite exponent parsing and Unicode Cc parity.
    text = replace_once(
        text,
        '''from __future__ import annotations\nimport json\nfrom pathlib import Path\nimport re\n''',
        '''from __future__ import annotations\nimport json\nimport math\nfrom pathlib import Path\nimport re\nimport unicodedata\n''',
        "android imports",
    )
    text = replace_once(
        text,
        '''def bad(value):\n    raise ValueError(f"nonfinite: {value}")\n\n\ndef depth(value):\n''',
        '''def bad(value):\n    raise ValueError(f"nonfinite: {value}")\n\n\ndef finite_float(value):\n    parsed = float(value)\n    if not math.isfinite(parsed):\n        raise ValueError(f"nonfinite: {value}")\n    return parsed\n\n\ndef depth(value):\n''',
        "android finite float",
    )
    text = replace_once(
        text,
        '''    value = json.loads(raw.decode("utf-8"), object_pairs_hook=pairs, parse_constant=bad)\n''',
        '''    value = json.loads(\n        raw.decode("utf-8"),\n        object_pairs_hook=pairs,\n        parse_constant=bad,\n        parse_float=finite_float,\n    )\n''',
        "android strict load",
    )
    text = replace_once(
        text,
        '''        and not any(ord(char) < 32 or ord(char) == 127 for char in value)\n''',
        '''        and not any(unicodedata.category(char) == "Cc" for char in value)\n''',
        "android control parity",
    )
    text = replace_once(
        text,
        '''        for kind in ("api", "state", "errors"):\n            label = compatibility["contracts"][kind]["logical_label"]\n            validate(load(directory / "golden/valid" / f"{kind}.json"), kind, module_id, label)\n            valid += 1\n''',
        '''        for path in sorted((directory / "golden/valid").glob("*.json")):\n            kind = path.name.split("-", 1)[0].split(".", 1)[0]\n            label = compatibility["contracts"][kind]["logical_label"]\n            validate(load(path), kind, module_id, label)\n            valid += 1\n''',
        "android all valid vectors",
    )

    # Compatibility checker: immutable base resolution and schema-aware fingerprinting.
    text = replace_once(
        text,
        '''from __future__ import annotations\nimport argparse\nimport json\nimport subprocess\nimport sys\nfrom pathlib import Path\n''',
        '''from __future__ import annotations\nimport argparse\nimport json\nimport math\nimport re\nimport subprocess\nimport sys\nfrom pathlib import Path\n''',
        "checker imports",
    )

    text = replace_once(
        text,
        '''def load(raw, label):\n    def pairs(items):\n        out = {}\n        for key, value in items:\n            if key in out:\n                raise ValueError(f"{label}: duplicate member {key}")\n            out[key] = value\n        return out\n    return json.loads(\n        raw.decode("utf-8"),\n        object_pairs_hook=pairs,\n        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(f"{label}: nonfinite {value}")),\n    )\n\n\ndef show(ref, path):\n    result = subprocess.run(\n        ["git", "--no-replace-objects", "show", f"{ref}:{path}"],\n        cwd=ROOT,\n        capture_output=True,\n        check=False,\n        timeout=30,\n    )\n    return result.stdout if result.returncode == 0 else None\n\n\nNON_SEMANTIC = {"$schema", "$id", "title", "description", "examples", "x-trillionnium-binding"}\n\n\ndef fingerprint(value):\n    if isinstance(value, dict):\n        return {\n            key: fingerprint(item)\n            for key, item in sorted(value.items())\n            if key not in NON_SEMANTIC\n        }\n    if isinstance(value, list):\n        return [fingerprint(item) for item in value]\n    return value\n''',
        '''def load(raw, label):\n    def pairs(items):\n        out = {}\n        for key, value in items:\n            if key in out:\n                raise ValueError(f"{label}: duplicate member {key}")\n            out[key] = value\n        return out\n\n    def finite_float(value):\n        parsed = float(value)\n        if not math.isfinite(parsed):\n            raise ValueError(f"{label}: nonfinite {value}")\n        return parsed\n\n    return json.loads(\n        raw.decode("utf-8"),\n        object_pairs_hook=pairs,\n        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(f"{label}: nonfinite {value}")),\n        parse_float=finite_float,\n    )\n\n\ndef git_result(*arguments):\n    return subprocess.run(\n        ["git", "--no-replace-objects", *arguments],\n        cwd=ROOT,\n        capture_output=True,\n        check=False,\n        timeout=30,\n    )\n\n\ndef resolve_commit(ref):\n    if not isinstance(ref, str) or not ref or ref.startswith("-"):\n        raise ValueError("base ref is invalid")\n    result = git_result("rev-parse", "--verify", "--end-of-options", f"{ref}^{{commit}}")\n    if result.returncode != 0:\n        raise ValueError(f"base ref does not resolve: {result.stderr.decode('utf-8', 'replace').strip()}")\n    values = result.stdout.decode("ascii").splitlines()\n    if len(values) != 1 or re.fullmatch(r"[0-9a-f]{40}", values[0]) is None:\n        raise ValueError("base ref did not resolve to one immutable commit")\n    commit = values[0]\n    ancestor = git_result("merge-base", "--is-ancestor", commit, "HEAD")\n    if ancestor.returncode != 0:\n        raise ValueError("base commit is not an ancestor of current HEAD")\n    return commit\n\n\ndef read_tree_file(commit, path):\n    listing = git_result("ls-tree", "-z", "--full-tree", commit, "--", path)\n    if listing.returncode != 0:\n        raise ValueError(f"cannot inspect verified base tree: {listing.stderr.decode('utf-8', 'replace').strip()}")\n    if not listing.stdout:\n        return None\n    entries = [entry for entry in listing.stdout.split(b"\\0") if entry]\n    if len(entries) != 1:\n        raise ValueError(f"verified base path is ambiguous: {path}")\n    metadata, separator, observed = entries[0].partition(b"\\t")\n    fields = metadata.split()\n    if not separator or observed.decode("utf-8") != path or len(fields) != 3 or fields[1] != b"blob":\n        raise ValueError(f"verified base path is not one regular blob: {path}")\n    object_id = fields[2].decode("ascii")\n    content = git_result("cat-file", "blob", object_id)\n    if content.returncode != 0:\n        raise ValueError(f"cannot read verified base blob: {path}")\n    return content.stdout\n\n\nNON_SEMANTIC = {"$schema", "$id", "title", "description", "examples", "x-trillionnium-binding"}\nNAMED_SCHEMA_MAPS = {\n    "$defs",\n    "definitions",\n    "dependencies",\n    "dependentSchemas",\n    "patternProperties",\n    "properties",\n}\nSUBSCHEMA_KEYS = {\n    "additionalItems",\n    "additionalProperties",\n    "contains",\n    "contentSchema",\n    "else",\n    "if",\n    "items",\n    "not",\n    "propertyNames",\n    "then",\n    "unevaluatedItems",\n    "unevaluatedProperties",\n}\nSUBSCHEMA_ARRAY_KEYS = {"allOf", "anyOf", "oneOf", "prefixItems"}\n\n\ndef literal_fingerprint(value):\n    if isinstance(value, dict):\n        return {key: literal_fingerprint(item) for key, item in sorted(value.items())}\n    if isinstance(value, list):\n        return [literal_fingerprint(item) for item in value]\n    return value\n\n\ndef fingerprint(value):\n    if isinstance(value, bool):\n        return value\n    if not isinstance(value, dict):\n        return literal_fingerprint(value)\n    result = {}\n    for key, item in sorted(value.items()):\n        if key in NON_SEMANTIC:\n            continue\n        if key in NAMED_SCHEMA_MAPS and isinstance(item, dict):\n            result[key] = {\n                name: fingerprint(schema) if isinstance(schema, (dict, bool)) else literal_fingerprint(schema)\n                for name, schema in sorted(item.items())\n            }\n        elif key in SUBSCHEMA_KEYS and isinstance(item, (dict, bool)):\n            result[key] = fingerprint(item)\n        elif key in SUBSCHEMA_KEYS and isinstance(item, list):\n            result[key] = [fingerprint(schema) for schema in item]\n        elif key in SUBSCHEMA_ARRAY_KEYS and isinstance(item, list):\n            result[key] = [fingerprint(schema) for schema in item]\n        else:\n            result[key] = literal_fingerprint(item)\n    return result\n''',
        "checker fail closed and context fingerprint",
    )

    text = replace_once(
        text,
        '''    current = load((ROOT / CATALOG).read_bytes(), CATALOG)\n    old_raw = show(args.base_ref, CATALOG)\n    if old_raw is None:\n''',
        '''    current = load((ROOT / CATALOG).read_bytes(), CATALOG)\n    base_commit = resolve_commit(args.base_ref)\n    old_raw = read_tree_file(base_commit, CATALOG)\n    if old_raw is None:\n''',
        "checker resolve base",
    )
    text = replace_once(
        text,
        '''            old_schema_raw = show(args.base_ref, old_path)\n''',
        '''            old_schema_raw = read_tree_file(base_commit, old_path)\n''',
        "checker base schema read",
    )

    # Rust consumer iterates normal and UTF-8 boundary valid vectors.
    text = replace_once(
        text,
        '''        for kind in ["api", "state", "errors"] {\n            let schema = compatibility["contracts"][kind]["logical_label"]\n                .as_str()\n                .expect("logical label");\n            let valid = fs::read(directory.join("golden/valid").join(format!("{kind}.json")))\n                .expect("valid vector");\n            match kind {\n                "api" => parse_module_api(&valid)\n                    .and_then(|value| value.validate_binding(schema, module_id))\n                    .expect("valid API vector"),\n                "state" => parse_module_state(&valid)\n                    .and_then(|value| value.validate_binding(schema, module_id))\n                    .expect("valid state vector"),\n                "errors" => parse_module_error(&valid)\n                    .and_then(|value| value.validate_binding(schema, module_id))\n                    .expect("valid error vector"),\n                _ => unreachable!(),\n            }\n        }\n''',
        '''        let mut valid_count = 0;\n        for entry in fs::read_dir(directory.join("golden/valid")).expect("valid vectors") {\n            let path = entry.expect("valid vector").path();\n            let name = path\n                .file_name()\n                .and_then(|value| value.to_str())\n                .expect("name");\n            let kind = name\n                .split_once('-')\n                .map(|(prefix, _)| prefix)\n                .unwrap_or_else(|| name.trim_end_matches(".json"));\n            let schema = compatibility["contracts"][kind]["logical_label"]\n                .as_str()\n                .expect("logical label");\n            let valid = fs::read(&path).expect("valid vector");\n            match kind {\n                "api" => parse_module_api(&valid)\n                    .and_then(|value| value.validate_binding(schema, module_id))\n                    .expect("valid API vector"),\n                "state" => parse_module_state(&valid)\n                    .and_then(|value| value.validate_binding(schema, module_id))\n                    .expect("valid state vector"),\n                "errors" => parse_module_error(&valid)\n                    .and_then(|value| value.validate_binding(schema, module_id))\n                    .expect("valid error vector"),\n                _ => panic!("unknown valid vector kind: {kind}"),\n            }\n            valid_count += 1;\n        }\n        assert_eq!(valid_count, 6, "valid vector count differs for {module_id}");\n''',
        "rust all valid vectors",
    )

    # Add multibyte boundary positives and overflow/control negatives.
    text = replace_once(
        text,
        '''        outputs[f"{base}/golden/valid/api.json"]=canonical_json(valid_api)\n        outputs[f"{base}/golden/valid/state.json"]=canonical_json(valid_state)\n        outputs[f"{base}/golden/valid/errors.json"]=canonical_json(valid_error)\n''',
        '''        outputs[f"{base}/golden/valid/api.json"]=canonical_json(valid_api)\n        outputs[f"{base}/golden/valid/state.json"]=canonical_json(valid_state)\n        outputs[f"{base}/golden/valid/errors.json"]=canonical_json(valid_error)\n        boundary_api=dict(valid_api)\n        boundary_api["operation_id"]="é" * 128\n        boundary_api["ordering_key"]="é" * 256\n        boundary_api["fencing_token"]="é" * 256\n        outputs[f"{base}/golden/valid/api-multibyte-boundary.json"]=canonical_json(boundary_api)\n        boundary_state=dict(valid_state)\n        boundary_state["operation_id"]="é" * 128\n        boundary_state["fencing_token"]="é" * 256\n        outputs[f"{base}/golden/valid/state-multibyte-boundary.json"]=canonical_json(boundary_state)\n        boundary_error=dict(valid_error)\n        boundary_error["operation_id"]="é" * 128\n        boundary_error["code"]="é" * 64\n        boundary_error["original_cause"]="é" * 2048\n        outputs[f"{base}/golden/valid/errors-multibyte-boundary.json"]=canonical_json(boundary_error)\n''',
        "generated valid utf8 boundary vectors",
    )
    text = replace_once(
        text,
        '''        invalid=dict(valid_error); invalid["module_id"]="MOD-CROSS-SPLICE"; outputs[f"{base}/golden/invalid/errors-module-splice.json"]=canonical_json(invalid)\n        compatibility_path=f"{base}/compatibility.json"\n''',
        '''        invalid=dict(valid_error); invalid["module_id"]="MOD-CROSS-SPLICE"; outputs[f"{base}/golden/invalid/errors-module-splice.json"]=canonical_json(invalid)\n        api_raw=json.dumps(valid_api,separators=(",",":"),ensure_ascii=False)\n        require(api_raw.count('"payload":{}')==1,"valid API payload rendering is ambiguous")\n        outputs[f"{base}/golden/invalid/api-nonfinite-positive-exponent.json"]=(api_raw.replace('"payload":{}','"payload":{"nested":[1e400]}')+"\\n").encode("utf-8")\n        outputs[f"{base}/golden/invalid/api-nonfinite-negative-exponent.json"]=(api_raw.replace('"payload":{}','"payload":{"nested":{"value":-1e400}}')+"\\n").encode("utf-8")\n        invalid=dict(valid_api); invalid["fencing_token"]="é" * 300; outputs[f"{base}/golden/invalid/api-fencing-multibyte-overflow.json"]=canonical_json(invalid)\n        invalid=dict(valid_api); invalid["ordering_key"]="session\\u0085turn"; outputs[f"{base}/golden/invalid/api-ordering-control.json"]=canonical_json(invalid)\n        invalid=dict(valid_error); invalid["code"]="é" * 65; outputs[f"{base}/golden/invalid/errors-code-multibyte-overflow.json"]=canonical_json(invalid)\n        invalid=dict(valid_error); invalid["original_cause"]="cause\\u0085detail"; outputs[f"{base}/golden/invalid/errors-cause-control.json"]=canonical_json(invalid)\n        compatibility_path=f"{base}/compatibility.json"\n''',
        "generated hostile numeric and text vectors",
    )

    text = replace_once(
        text,
        '''    lines=["# Module Contract Status","","<!-- GENERATED BY tools/contracts/generate_module_contracts.py. DO NOT EDIT. -->","",f"- Modules: `{len(records)}`","- API/state/error schemas: `3 per module`","- Shared valid vectors: `3 per module`","- Shared invalid vectors: `10 per module`",f"- Producer/consumer pairs: `{len(pairs)}`","- Schemars projection: `byte-bound`","- Automatic redispatch after uncertainty: `false`","- Public release: `false`","","| Module | API | State | Errors | Compatibility |","| --- | --- | --- | --- | --- |"]\n''',
        '''    lines=["# Module Contract Status","","<!-- GENERATED BY tools/contracts/generate_module_contracts.py. DO NOT EDIT. -->","",f"- Modules: `{len(records)}`","- API/state/error schemas: `3 per module`","- Shared valid vectors: `6 per module`","- Shared invalid vectors: `20 per module`",f"- Producer/consumer pairs: `{len(pairs)}`","- Schemars projection: `byte-bound`","- Automatic redispatch after uncertainty: `false`","- Public release: `false`","","| Module | API | State | Errors | Compatibility |","| --- | --- | --- | --- | --- |"]\n''',
        "status vector counts",
    )
    text = replace_once(
        text,
        '''        for path in sorted((base / "golden/valid").glob("*.json")):\n            kind=path.stem\n''',
        '''        for path in sorted((base / "golden/valid").glob("*.json")):\n            kind=path.name.split("-",1)[0].split(".",1)[0]\n''',
        "verify all valid vector kinds",
    )
    text = replace_once(
        text,
        '''        require(rejected==14,f"{record['module_id']} invalid vector count differs: {rejected}")\n''',
        '''        require(rejected==20,f"{record['module_id']} invalid vector count differs: {rejected}")\n''',
        "verify invalid vector count",
    )

    GENERATOR.write_text(text, encoding="utf-8")


def patch_tests() -> None:
    text = TESTS.read_text(encoding="utf-8")
    text = replace_once(
        text,
        '''import copy\nimport importlib.util\nimport json\nfrom pathlib import Path\nimport unittest\n''',
        '''import copy\nimport importlib.util\nimport json\nfrom pathlib import Path\nimport subprocess\nimport tempfile\nimport unittest\n''',
        "test imports",
    )
    text = replace_once(
        text,
        '''SCHEMARS = ROOT / "schemas/modules/_shared/envelopes-v1.schemars.json"\n\n\ndef load_generator():\n''',
        '''SCHEMARS = ROOT / "schemas/modules/_shared/envelopes-v1.schemars.json"\nCHECKER = ROOT / "tools/contracts/check_module_contract_compatibility.py"\n\n\ndef load_module(path: Path, name: str):\n    spec = importlib.util.spec_from_file_location(name, path)\n    if spec is None or spec.loader is None:\n        raise RuntimeError(f"cannot load {path}")\n    module = importlib.util.module_from_spec(spec)\n    spec.loader.exec_module(module)\n    return module\n\n\ndef load_generator():\n''',
        "test generic loader",
    )
    text = replace_once(
        text,
        '''def load_generator():\n    spec = importlib.util.spec_from_file_location("_module_contracts", GENERATOR)\n    if spec is None or spec.loader is None:\n        raise RuntimeError("cannot load module-contract generator")\n    module = importlib.util.module_from_spec(spec)\n    spec.loader.exec_module(module)\n    return module\n''',
        '''def load_generator():\n    return load_module(GENERATOR, "_module_contracts")\n''',
        "test generator loader",
    )
    text = replace_once(
        text,
        '''        with self.assertRaises(self.contracts.ContractError):\n            self.contracts.strict_load(b'{"a":NaN}', "nonfinite")\n''',
        '''        with self.assertRaises(self.contracts.ContractError):\n            self.contracts.strict_load(b'{"a":NaN}', "nonfinite")\n        with self.assertRaises(self.contracts.ContractError):\n            self.contracts.strict_load(b'{"a":{"b":[1e400]}}', "positive exponent overflow")\n        with self.assertRaises(self.contracts.ContractError):\n            self.contracts.strict_load(b'{"a":[{"b":-1e400}]}', "negative exponent overflow")\n''',
        "test exponent overflow",
    )
    text = replace_once(
        text,
        '''            for kind in ("api", "state", "errors"):\n                schema = json.loads(outputs[module["artifacts"][kind]])\n                path = f"schemas/modules/{module['slug']}/golden/valid/{kind}.json"\n                value = self.contracts.strict_load(outputs[path], path)\n                self.contracts.validate_schema(value, schema, path)\n                self.contracts.validate_semantics(\n                    value, kind, module["module_id"], module["logical_labels"][kind]\n                )\n            prefix = f"schemas/modules/{module['slug']}/golden/invalid/"\n            invalid = [path for path in outputs if path.startswith(prefix)]\n            self.assertEqual(len(invalid), 14)\n''',
        '''            valid_prefix = f"schemas/modules/{module['slug']}/golden/valid/"\n            valid = [path for path in outputs if path.startswith(valid_prefix)]\n            self.assertEqual(len(valid), 6)\n            for path in valid:\n                kind = Path(path).name.split("-", 1)[0].split(".", 1)[0]\n                schema = json.loads(outputs[module["artifacts"][kind]])\n                value = self.contracts.strict_load(outputs[path], path)\n                self.contracts.validate_schema(value, schema, path)\n                self.contracts.validate_semantics(\n                    value, kind, module["module_id"], module["logical_labels"][kind]\n                )\n            prefix = f"schemas/modules/{module['slug']}/golden/invalid/"\n            invalid = [path for path in outputs if path.startswith(prefix)]\n            self.assertEqual(len(invalid), 20)\n''',
        "test vector counts and all valid",
    )

    insertion = '''\n\nclass ModuleContractCompatibilityBoundaryTest(unittest.TestCase):\n    @classmethod\n    def setUpClass(cls) -> None:\n        cls.checker = load_module(CHECKER, "_module_contract_compatibility")\n\n    def test_fingerprint_ignores_annotations_but_preserves_named_properties(self) -> None:\n        left = {\n            "title": "first annotation",\n            "type": "object",\n            "properties": {\n                "title": {"type": "string", "description": "first field annotation"}\n            },\n            "required": ["title"],\n        }\n        annotation_only = copy.deepcopy(left)\n        annotation_only["title"] = "second annotation"\n        annotation_only["properties"]["title"]["description"] = "second field annotation"\n        self.assertEqual(\n            self.checker.fingerprint(left),\n            self.checker.fingerprint(annotation_only),\n        )\n        breaking = copy.deepcopy(left)\n        breaking["properties"]["title"]["type"] = "integer"\n        self.assertNotEqual(\n            self.checker.fingerprint(left),\n            self.checker.fingerprint(breaking),\n        )\n\n    def test_base_resolution_distinguishes_missing_ref_from_absent_path(self) -> None:\n        with tempfile.TemporaryDirectory() as temporary:\n            root = Path(temporary)\n            subprocess.run(["git", "init", "-q"], cwd=root, check=True)\n            subprocess.run(["git", "config", "user.name", "contract-test"], cwd=root, check=True)\n            subprocess.run(["git", "config", "user.email", "contract@example.invalid"], cwd=root, check=True)\n            (root / "README").write_text("base\\n", encoding="utf-8")\n            subprocess.run(["git", "add", "README"], cwd=root, check=True)\n            subprocess.run(["git", "commit", "-qm", "base"], cwd=root, check=True)\n            original = self.checker.ROOT\n            self.checker.ROOT = root\n            try:\n                commit = self.checker.resolve_commit("HEAD")\n                self.assertIsNone(self.checker.read_tree_file(commit, "absent.json"))\n                self.assertEqual(self.checker.read_tree_file(commit, "README"), b"base\\n")\n                with self.assertRaises(ValueError):\n                    self.checker.resolve_commit("does-not-exist-review-fixture")\n            finally:\n                self.checker.ROOT = original\n\n    def test_text_domain_is_utf8_byte_and_unicode_control_bounded(self) -> None:\n        contracts = load_generator()\n        self.assertTrue(contracts.valid_text("é" * 128, 256))\n        self.assertFalse(contracts.valid_text("é" * 129, 256))\n        self.assertFalse(contracts.valid_text("ordinary\\u0085control", 256))\n\n    def test_checker_rejects_exponent_overflow(self) -> None:\n        with self.assertRaises(ValueError):\n            self.checker.load(b'{"payload":{"nested":[1e400]}}', "positive")\n        with self.assertRaises(ValueError):\n            self.checker.load(b'{"payload":{"nested":{"value":-1e400}}}', "negative")\n'''
    text = replace_once(
        text,
        '''\n\nif __name__ == "__main__":\n    unittest.main()\n''',
        insertion + '''\n\nif __name__ == "__main__":\n    unittest.main()\n''',
        "append compatibility boundary tests",
    )
    TESTS.write_text(text, encoding="utf-8")


def main() -> None:
    patch_generator()
    patch_tests()
    print("PR75_CONTRACT_BOUNDARY_PATCH_APPLIED")


if __name__ == "__main__":
    main()
