#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

ROOT = Path.cwd()
GENERATOR = ROOT / "tools/contracts/generate_module_contracts.py"
TESTS = ROOT / "tools/tests/test_module_contracts.py"


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"{label}: expected one anchor, found {count}")
    return text.replace(old, new, 1)


generator = GENERATOR.read_text(encoding="utf-8")

change_review_helpers = r'''
CHANGE_REVIEW_CLASSES = {"NO_CHANGE", "BREAKING_MIGRATION"}
CHANGE_REVIEW_CONTRACTS = {"api", "state", "errors"}
CHANGE_REVIEW_FAMILIES = {
    "required",
    "type",
    "enum",
    "default",
    "identity",
    "ordering",
    "state",
    "error",
    "other",
}


def semantic_digest(value: Any) -> str:
    raw = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")
    return sha(raw)


def contract_change_review(
    item: dict[str, Any],
    target_contracts: dict[str, bytes],
) -> dict[str, Any]:
    mid = module_id(item)
    compatibility = item.get("compatibility")
    migration = item.get("migration")
    rollback = item.get("rollback")
    require(isinstance(compatibility, dict), f"{mid} compatibility is malformed")
    require(isinstance(migration, dict) and migration, f"{mid} migration metadata is malformed")
    require(isinstance(rollback, dict) and rollback, f"{mid} rollback metadata is malformed")
    require(set(target_contracts) == CHANGE_REVIEW_CONTRACTS, f"{mid} target contract set differs")

    source = compatibility.get("contract_change_review")
    migration_sha = semantic_digest(migration)
    rollback_sha = semantic_digest(rollback)
    if source is None:
        return {
            "class": "NO_CHANGE",
            "contracts": [],
            "families": [],
            "review_id": None,
            "migration_plan": None,
            "rollback_plan": None,
            "migration_review_sha256": migration_sha,
            "rollback_review_sha256": rollback_sha,
            "base_catalog_sha256": None,
            "base_contract_sha256": {},
            "target_contract_sha256": {},
        }

    require(isinstance(source, dict), f"{mid} contract change review is malformed")
    expected = {
        "class",
        "contracts",
        "families",
        "review_id",
        "migration_plan",
        "rollback_plan",
        "base_catalog_sha256",
        "base_contract_sha256",
        "target_contract_sha256",
    }
    require(set(source) == expected, f"{mid} contract change review keys differ")
    review_class = source.get("class")
    contracts = source.get("contracts")
    families = source.get("families")
    require(review_class in CHANGE_REVIEW_CLASSES, f"{mid} contract change review class is unknown")
    require(
        isinstance(contracts, list)
        and contracts == sorted(set(contracts))
        and set(contracts) <= CHANGE_REVIEW_CONTRACTS,
        f"{mid} contract change scope is malformed",
    )
    require(
        isinstance(families, list)
        and families == sorted(set(families))
        and set(families) <= CHANGE_REVIEW_FAMILIES,
        f"{mid} contract change families are malformed",
    )

    if review_class == "NO_CHANGE":
        require(not contracts and not families, f"{mid} NO_CHANGE carries a change scope")
        require(
            source.get("review_id") is None
            and source.get("migration_plan") is None
            and source.get("rollback_plan") is None
            and source.get("base_catalog_sha256") is None
            and source.get("base_contract_sha256") == {}
            and source.get("target_contract_sha256") == {},
            f"{mid} NO_CHANGE carries reusable review authority",
        )
    else:
        require(contracts and families, f"{mid} breaking review has no exact scope")
        for field, maximum in (
            ("review_id", 256),
            ("migration_plan", 4096),
            ("rollback_plan", 4096),
        ):
            require(
                valid_text(source.get(field), maximum),
                f"{mid} breaking review {field} is invalid",
            )
        require(
            isinstance(source.get("base_catalog_sha256"), str)
            and SHA64.fullmatch(source["base_catalog_sha256"]) is not None,
            f"{mid} breaking review base catalog digest is invalid",
        )
        for field in ("base_contract_sha256", "target_contract_sha256"):
            digests = source.get(field)
            require(
                isinstance(digests, dict) and set(digests) == set(contracts),
                f"{mid} breaking review {field} scope differs",
            )
            require(
                all(isinstance(value, str) and SHA64.fullmatch(value) for value in digests.values()),
                f"{mid} breaking review {field} digest is invalid",
            )
        require(
            all(
                source["target_contract_sha256"][kind] == sha(target_contracts[kind])
                for kind in contracts
            ),
            f"{mid} breaking review target digest does not bind generated bytes",
        )

    return {
        "class": review_class,
        "contracts": list(contracts),
        "families": list(families),
        "review_id": source.get("review_id"),
        "migration_plan": source.get("migration_plan"),
        "rollback_plan": source.get("rollback_plan"),
        "migration_review_sha256": migration_sha,
        "rollback_review_sha256": rollback_sha,
        "base_catalog_sha256": source.get("base_catalog_sha256"),
        "base_contract_sha256": dict(source.get("base_contract_sha256", {})),
        "target_contract_sha256": dict(source.get("target_contract_sha256", {})),
    }
'''

generator = replace_once(
    generator,
    "\n\ndef static_outputs() -> dict[str, bytes]:",
    "\n\n" + change_review_helpers.strip() + "\n\n\ndef static_outputs() -> dict[str, bytes]:",
    "insert change-review helpers",
)

generator = replace_once(
    generator,
    '''            "change_review_class":"INITIAL_V1",
            "breaking_change_review":"REQUIRED_FOR_REQUIRED_TYPE_ENUM_DEFAULT_IDENTITY_ORDERING_STATE_OR_ERROR_CHANGE",
            "migration_review":item["migration"],
            "rollback_review":item["rollback"],''',
    '''            "introduction_review_class":"INITIAL_V1",
            "change_review":contract_change_review(
                item,
                {
                    "api": outputs[api_path],
                    "state": outputs[state_path],
                    "errors": outputs[error_path],
                },
            ),
            "breaking_change_review":"REQUIRED_FOR_REQUIRED_TYPE_ENUM_DEFAULT_IDENTITY_ORDERING_STATE_OR_ERROR_CHANGE",
            "migration_review":item["migration"],
            "rollback_review":item["rollback"],''',
    "replace generated review class",
)

new_checker_function = r"""def compatibility_checker_source() -> bytes:
    return b'''#!/usr/bin/env python3
"Fail-closed semantic compatibility and one-shot change-review admission."
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import unicodedata
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
CATALOG = "docs/machine/module-contract-catalog.v1.json"
SHA40 = re.compile(r"^[0-9a-f]{40}$")
SHA64 = re.compile(r"^[0-9a-f]{64}$")
CHANGE_REVIEW_CLASSES = {"NO_CHANGE", "BREAKING_MIGRATION"}
CHANGE_REVIEW_CONTRACTS = {"api", "state", "errors"}
CHANGE_REVIEW_FAMILIES = {
    "required", "type", "enum", "default", "identity", "ordering",
    "state", "error", "other",
}
IDENTITY_FIELDS = {"schema", "module_id", "operation_id", "request_digest"}
ORDERING_FIELDS = {
    "ordering_key", "host_epoch", "writer_epoch", "fencing_token",
    "durable_sequence", "monotonic_ns",
}


def finite_float(raw: str) -> float:
    value = float(raw)
    if not math.isfinite(value):
        raise ValueError(f"nonfinite JSON number: {raw}")
    return value


def load(raw: bytes, label: str) -> Any:
    def pairs(items):
        out = {}
        for key, value in items:
            if key in out:
                raise ValueError(f"{label}: duplicate member {key}")
            out[key] = value
        return out

    return json.loads(
        raw.decode("utf-8"),
        object_pairs_hook=pairs,
        parse_constant=lambda value: (_ for _ in ()).throw(
            ValueError(f"{label}: nonfinite {value}")
        ),
        parse_float=finite_float,
    )


def canonical(value: Any) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def sha256_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def valid_text(value: Any, maximum: int) -> bool:
    if not isinstance(value, str) or not value:
        return False
    try:
        encoded = value.encode("utf-8")
    except UnicodeEncodeError:
        return False
    return len(encoded) <= maximum and not any(
        unicodedata.category(char) == "Cc" for char in value
    )


def git(args: list[str], label: str, *, root: Path = ROOT) -> bytes:
    result = subprocess.run(
        ["git", "--no-replace-objects", *args],
        cwd=root,
        capture_output=True,
        check=False,
        timeout=30,
    )
    if result.returncode != 0:
        detail = result.stderr.decode("utf-8", "replace").strip()
        raise ValueError(f"{label}: git returned {result.returncode}: {detail}")
    return result.stdout


def resolve_commit(ref: str, *, root: Path = ROOT) -> str:
    if not isinstance(ref, str) or not ref or "\\x00" in ref or "\\n" in ref:
        raise ValueError("base ref is malformed")
    raw = git(
        ["rev-parse", "--verify", "--end-of-options", f"{ref}^{{commit}}"],
        "resolve base ref",
        root=root,
    )
    values = raw.decode("ascii", "strict").splitlines()
    if len(values) != 1 or SHA40.fullmatch(values[0]) is None:
        raise ValueError("base ref did not resolve to one exact commit")
    commit = values[0]
    git(
        ["merge-base", "--is-ancestor", commit, "HEAD"],
        "verify base ancestry",
        root=root,
    )
    return commit


def show(
    commit: str,
    path: str,
    *,
    allow_absent: bool = False,
    root: Path = ROOT,
) -> bytes | None:
    if SHA40.fullmatch(commit) is None:
        raise ValueError("show requires an exact commit")
    if (
        not isinstance(path, str)
        or not path
        or path.startswith("/")
        or "\\\\" in path
        or "\\x00" in path
        or "\\n" in path
        or any(part in {"", ".", ".."} for part in path.split("/"))
    ):
        raise ValueError(f"unsafe tree path: {path!r}")

    listing = git(
        ["ls-tree", "-z", "--full-tree", commit, "--", path],
        f"inspect {path} in verified base",
        root=root,
    )
    entries = [entry for entry in listing.split(b"\\0") if entry]
    if not entries:
        if allow_absent:
            return None
        raise ValueError(f"verified base path is absent: {path}")
    if len(entries) != 1:
        raise ValueError(f"verified base path is ambiguous: {path}")

    metadata, separator, encoded_name = entries[0].partition(b"\\t")
    if not separator:
        raise ValueError(f"malformed ls-tree result for {path}")
    try:
        mode, kind, object_id = metadata.decode("ascii", "strict").split(" ")
        observed_name = encoded_name.decode("utf-8", "strict")
    except (UnicodeError, ValueError) as error:
        raise ValueError(f"malformed ls-tree identity for {path}") from error
    if (
        observed_name != path
        or kind != "blob"
        or mode not in {"100644", "100755"}
        or SHA40.fullmatch(object_id) is None
    ):
        raise ValueError(f"verified base object is not one regular tracked file: {path}")
    return git(["cat-file", "blob", object_id], f"read verified base file {path}", root=root)


NON_SEMANTIC = {
    "$schema", "$id", "title", "description", "examples",
    "x-trillionnium-binding",
}
NAMED_SCHEMA_MAPS = {
    "$defs", "definitions", "properties", "patternProperties",
    "dependentSchemas",
}
SCHEMA_SINGLE = {
    "additionalProperties", "unevaluatedProperties", "propertyNames",
    "contains", "contentSchema", "if", "then", "else", "not",
    "unevaluatedItems",
}
SCHEMA_ARRAYS = {"allOf", "anyOf", "oneOf", "prefixItems"}


def normalized_data(value: Any) -> Any:
    if isinstance(value, dict):
        return {
            key: normalized_data(item)
            for key, item in sorted(value.items())
        }
    if isinstance(value, list):
        return [normalized_data(item) for item in value]
    return value


def fingerprint(value: Any) -> Any:
    "Remove annotations only where the dictionary is a JSON Schema object."
    if isinstance(value, bool):
        return value
    if not isinstance(value, dict):
        return normalized_data(value)

    result = {}
    for key, item in sorted(value.items()):
        if key in NON_SEMANTIC:
            continue
        if key in NAMED_SCHEMA_MAPS and isinstance(item, dict):
            result[key] = {
                name: fingerprint(child)
                for name, child in sorted(item.items())
            }
        elif key == "dependencies" and isinstance(item, dict):
            result[key] = {
                name: (
                    fingerprint(child)
                    if isinstance(child, (dict, bool))
                    else normalized_data(child)
                )
                for name, child in sorted(item.items())
            }
        elif key in SCHEMA_SINGLE and isinstance(item, (dict, bool)):
            result[key] = fingerprint(item)
        elif key == "items":
            if isinstance(item, list):
                result[key] = [fingerprint(child) for child in item]
            elif isinstance(item, (dict, bool)):
                result[key] = fingerprint(item)
            else:
                result[key] = normalized_data(item)
        elif key in SCHEMA_ARRAYS and isinstance(item, list):
            result[key] = [fingerprint(child) for child in item]
        else:
            result[key] = normalized_data(item)
    return result


def semantic_change_families(old: Any, new: Any, kind: str) -> list[str]:
    old = fingerprint(old)
    new = fingerprint(new)
    families: set[str] = set()

    def mark(path: tuple[str, ...]) -> None:
        before = set(families)
        leaf = path[-1] if path else ""
        if leaf == "required" or "required" in path:
            families.add("required")
        if leaf == "type":
            families.add("type")
        if leaf == "enum":
            families.add("enum")
        if leaf == "default":
            families.add("default")
        if any(part in IDENTITY_FIELDS for part in path):
            families.add("identity")
        if any(part in ORDERING_FIELDS for part in path):
            families.add("ordering")
        if kind == "state":
            families.add("state")
        if kind == "errors":
            families.add("error")
        if families == before:
            families.add("other")

    def walk(left: Any, right: Any, path: tuple[str, ...]) -> None:
        if left == right:
            return
        if isinstance(left, dict) and isinstance(right, dict):
            for key in sorted(set(left) | set(right)):
                if key not in left or key not in right:
                    mark(path + (key,))
                else:
                    walk(left[key], right[key], path + (key,))
            return
        if isinstance(left, list) and isinstance(right, list):
            if path and path[-1] in {"required", "enum"}:
                mark(path)
                return
            for index in range(max(len(left), len(right))):
                if index >= len(left) or index >= len(right):
                    mark(path + (str(index),))
                else:
                    walk(left[index], right[index], path + (str(index),))
            return
        mark(path)

    walk(old, new, ())
    return sorted(families)


def validate_change_review(compatibility: Any, label: str) -> dict[str, Any]:
    if not isinstance(compatibility, dict):
        raise ValueError(f"{label}: compatibility metadata is not an object")
    if compatibility.get("introduction_review_class") != "INITIAL_V1":
        raise ValueError(f"{label}: introduction provenance differs")
    migration = compatibility.get("migration_review")
    rollback = compatibility.get("rollback_review")
    if not isinstance(migration, dict) or not migration:
        raise ValueError(f"{label}: migration metadata is missing")
    if not isinstance(rollback, dict) or not rollback or rollback.get("fail_closed") is not True:
        raise ValueError(f"{label}: rollback metadata is not fail-closed")

    review = compatibility.get("change_review")
    expected = {
        "class", "contracts", "families", "review_id", "migration_plan",
        "rollback_plan", "migration_review_sha256", "rollback_review_sha256",
        "base_catalog_sha256", "base_contract_sha256",
        "target_contract_sha256",
    }
    if not isinstance(review, dict) or set(review) != expected:
        raise ValueError(f"{label}: change review keys differ")
    review_class = review.get("class")
    if review_class not in CHANGE_REVIEW_CLASSES:
        raise ValueError(f"{label}: change review class is unknown")
    contracts = review.get("contracts")
    families = review.get("families")
    if (
        not isinstance(contracts, list)
        or contracts != sorted(set(contracts))
        or not set(contracts) <= CHANGE_REVIEW_CONTRACTS
    ):
        raise ValueError(f"{label}: change review contract scope is malformed")
    if (
        not isinstance(families, list)
        or families != sorted(set(families))
        or not set(families) <= CHANGE_REVIEW_FAMILIES
    ):
        raise ValueError(f"{label}: change review families are malformed")
    if review.get("migration_review_sha256") != sha256_bytes(canonical(migration)):
        raise ValueError(f"{label}: migration metadata digest differs")
    if review.get("rollback_review_sha256") != sha256_bytes(canonical(rollback)):
        raise ValueError(f"{label}: rollback metadata digest differs")

    if review_class == "NO_CHANGE":
        if contracts or families:
            raise ValueError(f"{label}: NO_CHANGE carries a change scope")
        if not (
            review.get("review_id") is None
            and review.get("migration_plan") is None
            and review.get("rollback_plan") is None
            and review.get("base_catalog_sha256") is None
            and review.get("base_contract_sha256") == {}
            and review.get("target_contract_sha256") == {}
        ):
            raise ValueError(f"{label}: NO_CHANGE carries reusable review authority")
    else:
        if not contracts or not families:
            raise ValueError(f"{label}: breaking review has no exact scope")
        for field, maximum in (
            ("review_id", 256),
            ("migration_plan", 4096),
            ("rollback_plan", 4096),
        ):
            if not valid_text(review.get(field), maximum):
                raise ValueError(f"{label}: breaking review {field} is invalid")
        if not isinstance(review.get("base_catalog_sha256"), str) or SHA64.fullmatch(
            review["base_catalog_sha256"]
        ) is None:
            raise ValueError(f"{label}: base catalog digest is invalid")
        for field in ("base_contract_sha256", "target_contract_sha256"):
            values = review.get(field)
            if not isinstance(values, dict) or set(values) != set(contracts):
                raise ValueError(f"{label}: {field} scope differs")
            if not all(
                isinstance(value, str) and SHA64.fullmatch(value)
                for value in values.values()
            ):
                raise ValueError(f"{label}: {field} digest is invalid")
    return review


def evaluate(root: Path, base_ref: str) -> dict[str, Any]:
    current = load((root / CATALOG).read_bytes(), CATALOG)
    base_commit = resolve_commit(base_ref, root=root)
    old_raw = show(base_commit, CATALOG, allow_absent=True, root=root)
    if old_raw is None:
        for module in current["modules"]:
            compatibility = load(
                (root / module["artifacts"]["compatibility"]).read_bytes(),
                module["module_id"],
            )
            review = validate_change_review(compatibility, module["module_id"])
            if review["class"] != "NO_CHANGE":
                raise ValueError("initial introduction carries a reusable change class")
        return {
            "base_commit": base_commit,
            "modules": current["module_count"],
            "public_release": False,
            "result": "PASS_INITIAL_V1",
        }

    old = load(old_raw, CATALOG)
    old_by = {item["module_id"]: item for item in old["modules"]}
    current_by = {item["module_id"]: item for item in current["modules"]}
    if set(old_by) != set(current_by):
        raise ValueError("module set changed without a separately reviewed catalog migration")

    changed: list[str] = []
    for module_id in sorted(current_by):
        current_record = current_by[module_id]
        old_record = old_by[module_id]
        compatibility = load(
            (root / current_record["artifacts"]["compatibility"]).read_bytes(),
            module_id,
        )
        old_compatibility_raw = show(
            base_commit, old_record["artifacts"]["compatibility"], root=root
        )
        old_compatibility = load(old_compatibility_raw, f"base {module_id}")
        review = validate_change_review(compatibility, module_id)
        validate_change_review(old_compatibility, f"base {module_id}")
        if compatibility["introduction_review_class"] != old_compatibility[
            "introduction_review_class"
        ]:
            raise ValueError(f"{module_id}: introduction provenance changed")

        changed_kinds: list[str] = []
        detected_families: set[str] = set()
        old_contract_raw: dict[str, bytes] = {}
        new_contract_raw: dict[str, bytes] = {}
        for kind in ("api", "state", "errors"):
            new_path = current_record["artifacts"][kind]
            old_path = old_record["artifacts"][kind]
            old_schema_raw = show(base_commit, old_path, root=root)
            new_schema_raw = (root / new_path).read_bytes()
            old_contract_raw[kind] = old_schema_raw
            new_contract_raw[kind] = new_schema_raw
            old_schema = load(old_schema_raw, old_path)
            new_schema = load(new_schema_raw, new_path)
            if fingerprint(old_schema) != fingerprint(new_schema):
                changed_kinds.append(kind)
                detected_families.update(
                    semantic_change_families(old_schema, new_schema, kind)
                )
                changed.append(f"{module_id}:{kind}")

        if not changed_kinds:
            if review["class"] != "NO_CHANGE":
                raise ValueError(f"{module_id}: stale breaking review was not reset")
            continue

        if review["class"] != "BREAKING_MIGRATION":
            raise ValueError(
                f"{module_id}: semantic schema drift lacks BREAKING_MIGRATION review"
            )
        if review["contracts"] != sorted(changed_kinds):
            raise ValueError(f"{module_id}: reviewed contract scope differs from detected drift")
        if review["families"] != sorted(detected_families):
            raise ValueError(f"{module_id}: reviewed change families differ from detected drift")
        if review["base_catalog_sha256"] != sha256_bytes(old_raw):
            raise ValueError(f"{module_id}: review does not bind the base catalog")
        for kind in changed_kinds:
            if review["base_contract_sha256"][kind] != sha256_bytes(
                old_contract_raw[kind]
            ):
                raise ValueError(f"{module_id}: review does not bind base {kind}")
            if review["target_contract_sha256"][kind] != sha256_bytes(
                new_contract_raw[kind]
            ):
                raise ValueError(f"{module_id}: review does not bind target {kind}")

    return {
        "base_commit": base_commit,
        "public_release": False,
        "result": "PASS",
        "semantic_changes": changed,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-ref", required=True)
    args = parser.parse_args()
    print(json.dumps(evaluate(ROOT, args.base_ref), sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, UnicodeError, ValueError, subprocess.SubprocessError) as error:
        print(f"module-contract compatibility failed: {error}", file=sys.stderr)
        raise SystemExit(2)
'''
"""

start = generator.index("def compatibility_checker_source() -> bytes:\n")
end = generator.index("\n\ndef contract_readme() -> bytes:", start)
generator = generator[:start] + new_checker_function + generator[end:]

GENERATOR.write_text(generator, encoding="utf-8")


tests = TESTS.read_text(encoding="utf-8")
new_test = r'''
    def test_change_review_state_machine_is_closed_and_one_shot(self) -> None:
        migration = {
            "from_versions": [],
            "to_version": "v1",
            "strategy": "none",
            "dual_read": False,
            "dual_write": False,
        }
        rollback = {
            "supported": False,
            "procedure": "fail_closed_fixture",
            "fail_closed": True,
        }

        def no_change_review():
            return {
                "class": "NO_CHANGE",
                "contracts": [],
                "families": [],
                "review_id": None,
                "migration_plan": None,
                "rollback_plan": None,
                "migration_review_sha256": self.checker.sha256_bytes(
                    self.checker.canonical(migration)
                ),
                "rollback_review_sha256": self.checker.sha256_bytes(
                    self.checker.canonical(rollback)
                ),
                "base_catalog_sha256": None,
                "base_contract_sha256": {},
                "target_contract_sha256": {},
            }

        def compatibility(review):
            return {
                "introduction_review_class": "INITIAL_V1",
                "change_review": review,
                "migration_review": migration,
                "rollback_review": rollback,
            }

        def write_json(path: Path, value) -> bytes:
            raw = json.dumps(
                value,
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
            ).encode("utf-8") + b"\n"
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
            return raw

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            subprocess.run(["git", "init", "-q"], cwd=root, check=True)
            subprocess.run(
                ["git", "config", "user.email", "fixture@example.invalid"],
                cwd=root,
                check=True,
            )
            subprocess.run(
                ["git", "config", "user.name", "fixture"], cwd=root, check=True
            )

            paths = {
                "api": "schemas/api.json",
                "state": "schemas/state.json",
                "errors": "schemas/errors.json",
                "compatibility": "schemas/compatibility.json",
            }
            catalog = {
                "module_count": 1,
                "modules": [
                    {
                        "module_id": "MOD-FIXTURE",
                        "artifacts": paths,
                    }
                ],
            }
            schemas = {
                "api": {
                    "type": "object",
                    "properties": {
                        "operation_id": {"type": "string", "maxLength": 256},
                        "ordering_key": {"type": "string", "maxLength": 512},
                        "payload": {"type": "object"},
                    },
                    "required": ["operation_id", "ordering_key", "payload"],
                },
                "state": {
                    "type": "object",
                    "properties": {
                        "state": {"type": "string", "enum": ["RECEIVED", "CLOSED"]},
                        "durable_sequence": {"type": "integer"},
                    },
                    "required": ["state", "durable_sequence"],
                },
                "errors": {
                    "type": "object",
                    "properties": {
                        "code": {"type": "string", "maxLength": 128},
                        "class": {"type": "string", "enum": ["TERMINAL_FAILURE"]},
                    },
                    "required": ["code", "class"],
                },
            }
            write_json(root / self.checker.CATALOG, catalog)
            for kind in ("api", "state", "errors"):
                write_json(root / paths[kind], schemas[kind])
            write_json(root / paths["compatibility"], compatibility(no_change_review()))
            subprocess.run(["git", "add", "."], cwd=root, check=True)
            subprocess.run(["git", "commit", "-qm", "base"], cwd=root, check=True)
            base = subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=root, text=True
            ).strip()
            base_catalog_raw = subprocess.check_output(
                ["git", "show", f"{base}:{self.checker.CATALOG}"], cwd=root
            )
            base_schema_raw = {
                kind: subprocess.check_output(
                    ["git", "show", f"{base}:{paths[kind]}"], cwd=root
                )
                for kind in ("api", "state", "errors")
            }

            self.assertEqual(
                self.checker.evaluate(root, base)["semantic_changes"], []
            )

            bad = no_change_review()
            bad["class"] = "INITIAL_V1"
            write_json(root / paths["compatibility"], compatibility(bad))
            with self.assertRaisesRegex(ValueError, "class is unknown"):
                self.checker.evaluate(root, base)
            bad["class"] = "ARBITRARY_APPROVAL"
            write_json(root / paths["compatibility"], compatibility(bad))
            with self.assertRaisesRegex(ValueError, "class is unknown"):
                self.checker.evaluate(root, base)

            cases = {
                "required": (
                    "api",
                    lambda value: value["required"].append("new_required"),
                ),
                "type": (
                    "api",
                    lambda value: value["properties"]["payload"].update(
                        {"type": "array"}
                    ),
                ),
                "enum": (
                    "api",
                    lambda value: value["properties"]["operation_id"].update(
                        {"enum": ["one", "two"]}
                    ),
                ),
                "default": (
                    "api",
                    lambda value: value["properties"]["payload"].update(
                        {"default": {}}
                    ),
                ),
                "identity": (
                    "api",
                    lambda value: value["properties"]["operation_id"].update(
                        {"maxLength": 255}
                    ),
                ),
                "ordering": (
                    "api",
                    lambda value: value["properties"]["ordering_key"].update(
                        {"maxLength": 511}
                    ),
                ),
                "state": (
                    "state",
                    lambda value: value["properties"]["state"].update(
                        {"enum": ["CLOSED"]}
                    ),
                ),
                "error": (
                    "errors",
                    lambda value: value["properties"]["code"].update(
                        {"maxLength": 127}
                    ),
                ),
            }
            for expected_family, (kind, mutate) in cases.items():
                with self.subTest(family=expected_family):
                    for restore_kind in ("api", "state", "errors"):
                        write_json(root / paths[restore_kind], schemas[restore_kind])
                    target = copy.deepcopy(schemas[kind])
                    mutate(target)
                    target_raw = write_json(root / paths[kind], target)
                    write_json(
                        root / paths["compatibility"],
                        compatibility(no_change_review()),
                    )
                    with self.assertRaisesRegex(
                        ValueError, "lacks BREAKING_MIGRATION review"
                    ):
                        self.checker.evaluate(root, base)

                    families = self.checker.semantic_change_families(
                        schemas[kind], target, kind
                    )
                    self.assertIn(expected_family, families)
                    reviewed = no_change_review()
                    reviewed.update(
                        {
                            "class": "BREAKING_MIGRATION",
                            "contracts": [kind],
                            "families": families,
                            "review_id": f"review-{expected_family}-fixture",
                            "migration_plan": "migrate exact bound fixture bytes",
                            "rollback_plan": "fail closed and restore exact base bytes",
                            "base_catalog_sha256": self.checker.sha256_bytes(
                                base_catalog_raw
                            ),
                            "base_contract_sha256": {
                                kind: self.checker.sha256_bytes(base_schema_raw[kind])
                            },
                            "target_contract_sha256": {
                                kind: self.checker.sha256_bytes(target_raw)
                            },
                        }
                    )
                    write_json(
                        root / paths["compatibility"], compatibility(reviewed)
                    )
                    result = self.checker.evaluate(root, base)
                    self.assertEqual(
                        result["semantic_changes"], [f"MOD-FIXTURE:{kind}"]
                    )

            for kind in ("api", "state", "errors"):
                write_json(root / paths[kind], schemas[kind])
            stale = no_change_review()
            stale.update(
                {
                    "class": "BREAKING_MIGRATION",
                    "contracts": ["api"],
                    "families": ["type"],
                    "review_id": "stale-review-fixture",
                    "migration_plan": "stale migration",
                    "rollback_plan": "stale rollback",
                    "base_catalog_sha256": self.checker.sha256_bytes(
                        base_catalog_raw
                    ),
                    "base_contract_sha256": {
                        "api": self.checker.sha256_bytes(base_schema_raw["api"])
                    },
                    "target_contract_sha256": {
                        "api": self.checker.sha256_bytes(base_schema_raw["api"])
                    },
                }
            )
            write_json(root / paths["compatibility"], compatibility(stale))
            with self.assertRaisesRegex(ValueError, "stale breaking review"):
                self.checker.evaluate(root, base)

    def test_initial_introduction_uses_provenance_not_reusable_change_class(self) -> None:
        outputs = self.outputs()
        catalog = json.loads(outputs[self.contracts.CONTRACT_CATALOG_PATH])
        for module in catalog["modules"]:
            compatibility = json.loads(outputs[module["artifacts"]["compatibility"]])
            self.assertEqual(
                compatibility["introduction_review_class"], "INITIAL_V1"
            )
            self.assertEqual(compatibility["change_review"]["class"], "NO_CHANGE")
            self.assertEqual(compatibility["change_review"]["contracts"], [])
            self.assertEqual(compatibility["change_review"]["families"], [])
'''

tests = replace_once(
    tests,
    "\n    def test_lock_binds_every_generated_artifact_except_itself(self) -> None:",
    "\n" + new_test.rstrip() + "\n\n    def test_lock_binds_every_generated_artifact_except_itself(self) -> None:",
    "insert review-class tests",
)
TESTS.write_text(tests, encoding="utf-8")

print("PR75_REVIEW_CLASS_STATE_MACHINE_PATCH_APPLIED")
