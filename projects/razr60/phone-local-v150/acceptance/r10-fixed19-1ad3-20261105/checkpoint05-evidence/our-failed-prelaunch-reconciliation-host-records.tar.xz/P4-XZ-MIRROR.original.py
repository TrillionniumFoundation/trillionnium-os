import pathlib,os,stat,json,hashlib,zlib,lzma,tarfile,io
root=pathlib.Path('/home/alex/razr60-local-model-v150/fixed19-root-1ad3-neg01-failure-evidence01')
assert root.resolve(strict=True)==root
src=root/'SENDER-ORIGINALS.tar.gz';raw=src.read_bytes()
assert len(raw)==875556 and hashlib.sha256(raw).hexdigest()=='54417cfcfdf35a2fd58d79b99245dbc46ad4250a01d029583a3e2b6fa2f07229'
d=zlib.decompressobj(31);plain=d.decompress(raw,8388609)
assert len(plain)<=8388608 and d.eof and not d.unconsumed_tail and not d.unused_data
mf=(root/'MANIFEST.json').read_bytes();assert hashlib.sha256(mf).hexdigest()=='b282ea02397708fc115f4f58365cad7a5751843d2b0f9abd603b5858fbbbcc43'
v=json.loads(mf);expected={'sender-originals/'+f['relative_path']:(f['bytes'],f['sha256']) for f in v['files']};expected['P4-SENDER-INVENTORY.original.json']=(51164,'6ddc71d0373be9e293fb1b32548160929936def2a47ca8b36b788bc0c75fe42d')
seen=set()
with tarfile.open(fileobj=io.BytesIO(plain),mode='r:') as t:
 for member in t:
  assert member.isfile() and member.name in expected and member.name not in seen
  b=t.extractfile(member).read();assert (len(b),hashlib.sha256(b).hexdigest())==expected[member.name];seen.add(member.name)
assert seen==set(expected)
x=lzma.compress(plain,format=lzma.FORMAT_XZ,check=lzma.CHECK_CRC64,preset=6)
assert lzma.decompress(x)==plain
fd=os.open(root/'SENDER-ORIGINALS.tar.xz',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
with os.fdopen(fd,'wb') as f:f.write(x);f.flush();os.fsync(f.fileno())
result={'schema':'hepta.fixed19.lossless-evidence-mirror.v1','state':'SAME_ORIGINAL_TAR_BYTES_RETAINED_WITH_XZ','source_archive':{'path':str(src),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},'tar_plaintext':{'bytes':len(plain),'sha256':hashlib.sha256(plain).hexdigest()},'archive':{'path':str(root/'SENDER-ORIGINALS.tar.xz'),'bytes':len(x),'sha256':hashlib.sha256(x).hexdigest()},'verified_regular_members':len(seen),'source_manifest_sha256':hashlib.sha256(mf).hexdigest(),'originals_changed':False,'phone_calls':0,'case_pass':False}
b=(json.dumps(result,sort_keys=True,indent=2)+'\n').encode()
fd=os.open(root/'XZ-MIRROR-RESULT.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
fd=os.open(root,os.O_RDONLY);os.fsync(fd);os.close(fd)
print(json.dumps(result,sort_keys=True))
