import pathlib,json,hashlib,stat,time,os
p=pathlib.Path('/home/alex/codex-hepta-natural-root-r10-neg01-1ad3-01-root-v150')
rows=[]
for q in sorted(p.rglob('*')):
 s=q.lstat()
 if stat.S_ISREG(s.st_mode):
  assert not q.is_symlink() and s.st_nlink==1
  rows.append({'path':str(q),'relative_path':q.relative_to(p).as_posix(),'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'sha256':hashlib.sha256(q.read_bytes()).hexdigest() if s.st_size<=1048576 else None})
 elif not stat.S_ISDIR(s.st_mode):raise ValueError('unexpected nonregular')
print(json.dumps({'state':'READ_ONLY_EXISTING_ORIGINAL_SENDER_INVENTORY','observed_unix_ms':time.time_ns()//1000000,'path':str(p),'exists':p.exists(),'file_count':len(rows),'files':rows},sort_keys=True))
