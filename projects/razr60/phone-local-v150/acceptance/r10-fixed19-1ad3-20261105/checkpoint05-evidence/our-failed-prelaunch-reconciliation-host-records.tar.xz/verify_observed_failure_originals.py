#!/usr/bin/env python3
"""Verify retained originals; never creates a native boundary or case PASS."""
import base64
import hashlib
import io
import json
import lzma
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
CASE = BASE.parent
NONCE = '7c74b84aefb177d15f746fa7eae29d54'
PROMPT = '6cde40708b387361d0115eb65f0e39c61872f8146a593cf4a8cb4890202ff525'
CONTRACT = 'd44c17956cff7c94f4cf3527b591908c70cc5d8df66049f385a068bab6174b66'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def original(relative, digest=None):
    path = BASE / relative
    raw = path.read_bytes()
    if digest is not None:
        assert sha(raw) == digest
    return raw


def main():
    archive = original('SENDER-ORIGINALS.tar.xz', '7623360614d74de0b77416605f8a86019f052984d9e6beb94dc6f7699b09f11a')
    plain = lzma.decompress(archive)
    assert len(plain) == 5539840 and sha(plain) == '772033a80262d51515122bf65c0b52aacf3d8936ad94950a87982db75c387542'
    inventory_raw = original('P4-SENDER-INVENTORY.original.json', '6ddc71d0373be9e293fb1b32548160929936def2a47ca8b36b788bc0c75fe42d')
    inventory = json.loads(inventory_raw)
    expected = {'sender-originals/' + row['relative_path']: (row['bytes'], row['sha256']) for row in inventory['files']}
    expected['P4-SENDER-INVENTORY.original.json'] = (len(inventory_raw), sha(inventory_raw))
    files = {}
    with tarfile.open(fileobj=io.BytesIO(plain), mode='r:') as reader:
        for member in reader:
            assert member.isfile() and member.name in expected and member.name not in files
            raw = reader.extractfile(member).read()
            assert (len(raw), sha(raw)) == expected[member.name]
            files[member.name] = raw
    assert set(files) == set(expected) and len(files) == 171
    originals = {key.removeprefix('sender-originals/'): raw for key, raw in files.items() if key.startswith('sender-originals/')}
    assert len(originals) == 170 and sum(map(len, originals.values())) == 5362795
    assert not [name for name in originals if name.startswith('SEND')]
    def value(name):
        return json.loads(originals[name])
    marker = value('COMPONENT-PREPARED-NO-SEND.json')
    assert marker['nonce'] == NONCE and marker['owner_request_sha256'] == PROMPT
    assert marker['contract_sha256'] == CONTRACT and marker['state'] == 'PREPARED_NO_SEND'
    assert marker['send_attempt_count'] == 0 and marker['provider_started_by_sender'] is False
    ready_names = sorted(name for name in originals if name.startswith('COMPONENT-READY-'))
    assert ready_names == [f'COMPONENT-READY-{number:04d}.original-read.json' for number in range(1, 143)]
    prior_end = marker['prepared_monotonic_ns']
    for name in ready_names:
        observed = value(name)
        wire = observed['original_wire_receipt']
        assert observed['read_only'] is True and observed['socket_connections'] == observed['service_launches'] == 0
        assert wire['rc'] == 0 and wire['stderr'] == ''
        parsed = json.loads(wire['stdout'])
        assert observed['observation'] == parsed
        assert parsed == {'state': 'waiting_for_ready', 'contract_sha256': CONTRACT, 'nonce': NONCE,
                          'owner_request_sha256': PROMPT, 'claim_absent': True, 'ended_absent': True}
        assert prior_end <= observed['read_start_monotonic_ns'] <= observed['read_end_monotonic_ns']
        assert observed['read_end_monotonic_ns'] < marker['pre_send_deadline_monotonic_ns']
        prior_end = observed['read_end_monotonic_ns']
    failure = value('ACTOR-FAILURE.json')
    assert failure == {'error_type': 'RuntimeError', 'error': 'Component rendezvous deadline elapsed; zero Send, no provider restart',
                       'automatic_send_retry': False}
    host_raw = original('root-r10-neg01-1ad3-01.send-result.json', '3a8ffc3ce20efd74d2e30d0763ae46ae32adea667d528f6e554170c067293932')
    host = json.loads(host_raw)
    assert host['rc'] == 2 and host['stderr'] == '' and len(host['stdout'].splitlines()) == 1
    actor = json.loads(host['stdout'])
    assert actor['state'] == 'PRE_SEND_OR_ACTOR_FAILURE' and actor['prompt_sha256'] == PROMPT
    assert actor['send_attempt_count'] == 0 and actor['automatic_replay'] is False and actor['business_success_verified'] is False
    assert actor['draft_restore'] == {'state': 'ORIGINAL_DRAFT_RESTORED', 'restore_attempts': 1, 'original_draft_submitted': False}
    preserved = value('PRESERVED-USER-DRAFT.json')
    assert preserved['submitted_original_draft'] is False
    assert sha(preserved['exact_text'].encode()) == preserved['utf8_sha256']
    restore = value('PRESERVED-DRAFT-RESTORE.original.json')
    assert restore['rc'] == 0 and restore['stderr'] == ''
    readback = json.loads(restore['stdout'])
    assert readback['status'] == 'set_verified' and readback['effect_state'] == 'observed_exact_requested_text'
    assert readback['before_utf8_sha256'] == PROMPT
    assert readback['requested_utf8_sha256'] == readback['after_utf8_sha256'] == preserved['utf8_sha256']
    assert base64.b64decode(readback['readback_text_b64'], validate=True) == preserved['exact_text'].encode()
    assert readback['own_automation_disconnected'] is True
    restored = value('DRAFT-RESTORE-RESULT.json')
    assert restored['state'] == 'ORIGINAL_DRAFT_RESTORED' and restored['utf8_sha256'] == preserved['utf8_sha256']
    assert restored['restore_attempts'] == 1 and restored['original_draft_submitted'] is False
    assert originals['FINAL-PRE-SEND-SELECTED.original-read.json'] == originals['RESTORE-SELECTED.original-read.json'] == originals['RESTORE-SELECTED-FINAL.original-read.json']
    assert originals['FINAL-PRE-SEND-RETIREMENT.original-read.json'] == originals['RESTORE-GLOBAL-GATE.original-read.json']
    root_raw = (CASE / 'ROOT-FAILURE.json').read_bytes()
    assert sha(root_raw) == '160d7a942ef1a94efe79319475db1d0d87d38a5d58b941b3e0689417d7e6fbc2'
    root = json.loads(root_raw)
    assert root['detail'] == 'same lease exhausted; no extension/restart' and root['root_fixture_attempts'] == []
    assert root['component_qualified'] is False and root['business_qualified'] is False and root['send_again'] is False
    absence_raw = original('MAC-SENDER-ABSENCE.original.json', '8d2e1fc9e990da7d4d017de20f3888b27cebb848a4faa5a9a0334c2d9b09d24b')
    absence = json.loads(absence_raw)
    assert absence['original_sender_pid'] == absence['original_pgid'] == 87157
    assert len(absence['observations']) == 2
    assert all(row['ps_returncode'] == 0 and row['ps_stderr'] == '' and row['matching_process_count'] == 0
               and row['owned_pid_or_group_or_exact_label_rows'] == [] for row in absence['observations'])
    assert absence['original_parent_join_proven'] is False and absence['original_capture_eof_repaired'] is False
    stage_raw = original('phone-stage-read01/PHONE-STDOUT.original', '6c1ec237f163a1474ba74613f01d720400f5fd666ed8a4c8cd6349744d51c163')
    stage = json.loads(stage_raw)
    assert stage['state'] == 'EXACT_STAGED_TREE_RETAINED_NO_LAUNCH_ARTIFACTS_OBSERVED'
    assert stage['nonce'] == NONCE and stage['lease_expired'] is True
    assert stage['exact_current_file_count'] == 57 and stage['exact_current_directory_count'] == 9
    assert len(stage['explicit_absence']) == 29 and set(stage['explicit_absence'].values()) == {'ENOENT_AT_HELD_PARENT_BEFORE_AND_AFTER_READSET'}
    assert stage['journal']['empty'] is True and stage['journal']['exact_original_seed_metadata'] is True and stage['journal']['both_views_equal'] is True
    assert stage['full9_named_fd_and_canonical_path_bookends'] is True
    assert stage['native_boundary_created'] is False and stage['failed_predecessor_closed_here'] is False
    native = json.loads(original('phone-stage-read01/phone-result.json.original', 'aab2cd60a40d0648b343c605bda41b19282477ec973a9a5176278469152bc6b2'))
    assert native['phone']['rc'] == 0 and native['phone']['stderr'] == '' and native['phone']['stdout'].encode() == stage_raw
    report = {'schema': 'hepta.fixed19.failed-prelaunch-observed-evidence-review.v1',
              'state': 'OBSERVED_SENDER_AND_PRIVATE_STAGE_RECONCILED_GLOBAL_RECHECK_PENDING',
              'case_id': 'NEG-01', 'nonce': NONCE, 'original_case_failed': True,
              'sender_original_files': 170, 'sender_original_bytes': 5362795, 'all_archive_members_verified': 171,
              'ready_wait_originals': 142, 'all_ready_waits_no_claim_no_service_no_socket': True,
              'sender_result_rc': 2, 'send_attempt_count': 0, 'send_named_records_present': [],
              'draft_original_exact_bytes_restored_and_read_back': True, 'restore_attempts': 1,
              'selected_identity_readback_unchanged_during_sender': True, 'retirement_readback_unchanged_during_sender': True,
              'mac_sender_pid_and_group_absence_observations': 2, 'original_parent_join_retrofitted': False,
              'original_root_capture_eof_retrofitted': False, 'private_stage_original_files': 57,
              'explicit_launch_acceptance_absences': 29, 'empty_executor_original_seed_verified': True,
              'last_real_native_boundary': 'root-r10-neg01-20261105-08',
              'live_retirement_full_inventory_groups_endpoints_recheck_pending': True,
              'new_owner_hash_global_publication_check_pending': True,
              'failed_predecessor_closed': False, 'native_boundary_created': False,
              'whole_cases_passed': 0, 'component_qualified': False, 'business_qualified': False,
              'automatic_retry_authorized_here': False,
              'original_root_failure_sha256': sha(root_raw), 'sender_archive_sha256': sha(archive),
              'sender_host_result_sha256': sha(host_raw), 'phone_stage_observation_sha256': sha(stage_raw),
              'mac_sender_absence_sha256': sha(absence_raw)}
    raw = (json.dumps(report, sort_keys=True, ensure_ascii=False, indent=2) + '\n').encode()
    destination = BASE / 'OBSERVED-EVIDENCE-REVIEW01.json'
    if destination.exists():
        assert destination.read_bytes() == raw
    else:
        destination.write_bytes(raw)
    print(json.dumps({'path': str(destination), 'bytes': len(raw), 'sha256': sha(raw), 'state': report['state'], 'case_pass': False}, sort_keys=True))


if __name__ == '__main__':
    main()
