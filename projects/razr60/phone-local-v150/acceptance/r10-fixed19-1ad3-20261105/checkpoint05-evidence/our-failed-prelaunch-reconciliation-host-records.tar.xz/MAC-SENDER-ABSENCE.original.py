import subprocess,json,time,os
label='root-r10-neg01-1ad3-01';pid=87157;observations=[]
for index in range(2):
 p=subprocess.run(['/bin/ps','-axo','pid=,ppid=,pgid=,sess=,lstart=,command='],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False,timeout=10)
 assert p.returncode==0,p.stderr.decode()
 rows=[]
 for line in p.stdout.decode().splitlines():
  parts=line.split(None,9)
  if len(parts)==10 and (parts[0]==str(pid) or parts[2]==str(pid) or label in parts[9]):rows.append(line)
 observations.append({'index':index,'observed_unix_ms':time.time_ns()//1000000,'ps_returncode':p.returncode,'ps_stderr':p.stderr.decode(),'owned_pid_or_group_or_exact_label_rows':rows,'matching_process_count':len(rows)})
 if index==0:time.sleep(1)
print(json.dumps({'schema':'hepta.fixed19.failed-sender-readonly-process-observation.v1','label':label,'original_sender_pid':pid,'original_pgid':pid,'observations':observations,'signals_sent':0,'original_parent_join_proven':False,'original_capture_eof_repaired':False,'case_pass':False},sort_keys=True))
