#!/usr/bin/env python3
"""Fixed two-attempt publication and selected-state read. Never writes or launches."""
import sys
sys.dont_write_bytecode=True
import errno
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import time

BOOT='f8019f83-20a7-4f18-bea1-51c980621e4d'
BASE=Path('/var/lib/trillionnium/owner-open/phone-local-v150')
ANDROID=Path('/proc/1/root')
ATTEMPTS=(
 {'label':'root-r10-neg01-20261105-09','nonce':'7c79195945d64e569a191166ac122a08',
  'owner_request_sha256':'83552b168a1d10718dcea0177c00e50ca44c4b2cb10d484a7abf888bc15b1b07',
  'lease_expires_unix_ms':1793871987099},
 {'label':'root-r10-neg01-1ad3-01','nonce':'7c74b84aefb177d15f746fa7eae29d54',
  'owner_request_sha256':'6cde40708b387361d0115eb65f0e39c61872f8146a593cf4a8cb4890202ff525',
  'lease_expires_unix_ms':1793872564534})
SELECTED_PIN=(249,'575d638551680a55c51b9ef404c91dcc7dd770db1e025a1a09672974a4cf3530')
ACTUAL08={'bytes':9373,'metadata':[65086,153711,33152,0,0,1,9373,1793853757339925229,1793853757339925229],
 'path':str(BASE/'native-guard-boundaries-r10-r1/2b0b103ee6de7a422064b9571266bf5d.json'),
 'sha256':'eca941303197228ebe03561e612bfe41eb0518c590ff21253444db25a11adc10'}
META=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
MAX_FILE=16*1024*1024
MAX_READ=64*1024*1024
MAX_OUTPUT=1024*1024
START=None
READ_TOTAL=0
FILES={}
DIRECTORIES={}
ABSENT={}
USER_ZERO=None
USER_ZERO_VIEW=None

def need(ok,why):
    if not ok:raise ValueError(why)

def check():need(time.monotonic()-START<30,'fixed scoped read exceeds 30-second cooperative budget')

def sha(raw):return hashlib.sha256(raw).hexdigest()

def meta(s):return [getattr(s,key) for key in META]

def strict(raw):
    def pairs(rows):
        value={}
        for key,item in rows:
            need(key not in value,'duplicate JSON key');value[key]=item
        return value
    return json.loads(raw,object_pairs_hook=pairs,
        parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))

def parent_fd(path):
    path=Path(path)
    need(path.is_absolute() and '..' not in path.parts and 2<=len(path.parts)<=64,'bounded absolute path')
    if path.parts[:4]==('/','proc','1','root'):
        fd=os.open(ANDROID,os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC);parts=path.parts[4:]
    else:
        fd=os.open('/',os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC);parts=path.parts[1:]
    need(parts,'original leaf required')
    try:
        for name in parts[:-1]:
            child=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd)
            os.close(fd);fd=child
        return fd,parts[-1]
    except BaseException:
        os.close(fd);raise

def directory(path):
    check();path=Path(path);parent,leaf=parent_fd(path)
    try:
        fd=os.open(leaf,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent)
        try:
            before=os.fstat(fd);names=sorted(os.listdir(fd))
            need(stat.S_ISDIR(before.st_mode) and before.st_uid==before.st_gid==0
                 and stat.S_IMODE(before.st_mode)==0o700 and len(names)<=1024,'private scoped directory shape')
            need(meta(before)==meta(os.fstat(fd))==meta(os.stat(leaf,dir_fd=parent,follow_symlinks=False)),
                 'directory full9 changed while read')
        finally:os.close(fd)
    finally:os.close(parent)
    row={'metadata':meta(before),'names':names}
    if str(path) in DIRECTORIES:need(DIRECTORIES[str(path)]==row,'scoped directory changed across read')
    else:DIRECTORIES[str(path)]=row
    return row

def read(path,maximum=MAX_FILE,root_owned=True):
    global READ_TOTAL
    check();path=Path(path);parent,leaf=parent_fd(path)
    try:
        fd=os.open(leaf,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent)
        try:
            before=os.fstat(fd)
            need(stat.S_ISREG(before.st_mode) and before.st_nlink==1 and stat.S_IMODE(before.st_mode)==0o600
                 and 0<=before.st_size<=maximum,'bounded private regular original required')
            if root_owned:need(before.st_uid==before.st_gid==0,'root-owned scoped original required')
            with os.fdopen(fd,'rb',closefd=False) as stream:raw=stream.read(before.st_size+1)
            need(len(raw)==before.st_size and meta(before)==meta(os.fstat(fd))
                 ==meta(os.stat(leaf,dir_fd=parent,follow_symlinks=False)),'original full9 changed while read')
        finally:os.close(fd)
    finally:os.close(parent)
    READ_TOTAL+=len(raw);need(READ_TOTAL<=MAX_READ,'scoped original read bytes exceeded')
    row={'bytes':len(raw),'sha256':sha(raw),'metadata':meta(before),'root_owned':root_owned}
    if str(path) in FILES:need(FILES[str(path)]==row,'original changed across complete readset')
    else:
        need(len(FILES)<1024,'scoped original count exceeded');FILES[str(path)]=row
    return raw

def absent(path):
    check();path=Path(path);parent,leaf=parent_fd(path)
    try:
        before=os.fstat(parent)
        try:os.stat(leaf,dir_fd=parent,follow_symlinks=False)
        except OSError as exc:need(exc.errno==errno.ENOENT,'absence is unknown')
        else:raise ValueError('forbidden pending or failed-nonce publication is present')
        need(meta(before)==meta(os.fstat(parent)),'absence parent changed')
        second,name=parent_fd(path)
        try:
            need(name==leaf and meta(os.fstat(second))==meta(before),'absence canonical parent changed')
            try:os.stat(name,dir_fd=second,follow_symlinks=False)
            except OSError as exc:need(exc.errno==errno.ENOENT,'second absence is unknown')
            else:raise ValueError('absent path appeared on canonical reopen')
        finally:os.close(second)
    finally:os.close(parent)
    row={'state':'ENOENT_AT_HELD_PARENT_AND_CANONICAL_REOPEN','parent_metadata':meta(before)}
    if str(path) in ABSENT:need(ABSENT[str(path)]==row,'absence parent changed across complete readset')
    else:ABSENT[str(path)]=row

def app_user_zero():
    """Only the fixed Android user-0 directory or its exact data/data alias."""
    global USER_ZERO,USER_ZERO_VIEW
    p=ANDROID/'data/user/0';parent,leaf=parent_fd(p)
    try:
        before=os.stat(leaf,dir_fd=parent,follow_symlinks=False)
        if stat.S_ISLNK(before.st_mode):
            target=os.readlink(leaf,dir_fd=parent)
            need(target in ('/data/data','../data'),'unreviewed Android user-0 alias')
            selected=ANDROID/'data/data'
        else:
            need(stat.S_ISDIR(before.st_mode),'Android user-0 is not a directory');target=None;selected=p
        need(meta(before)==meta(os.stat(leaf,dir_fd=parent,follow_symlinks=False)),
             'Android user-0 anchor changed')
    finally:os.close(parent)
    row={'original_path':str(p),'metadata':meta(before),'literal_link_target':target,'selected_anchor':str(selected)}
    if USER_ZERO_VIEW is None:USER_ZERO_VIEW=row;USER_ZERO=selected
    else:need(row==USER_ZERO_VIEW and selected==USER_ZERO,'Android selected-state anchor changed')
    return selected/'org.trillionnium.owneropen/files'

def selected_state():
    parent=app_user_zero();pending=parent/'owner-client-session-v1.pending'
    absent(pending);raw=read(parent/'owner-client-session-v1.bin',65536,root_owned=False);absent(pending)
    need((len(raw),sha(raw))==SELECTED_PIN,'current selected task bytes differ from final actor CAS readback')
    return {'bytes':len(raw),'sha256':sha(raw),'file':str(parent/'owner-client-session-v1.bin'),
            'pending_absent':True,'matches_original_actor_final_readback':True}

def provider_starts():
    wanted={row['owner_request_sha256'] for row in ATTEMPTS};scanned=[];matches=[];missing=[];runs=0;lines=0
    for mode,root in [('production',BASE/'provider-state/evidence'),('component',BASE/'component-probe-r6/evidence')]:
        names=directory(root)['names'];need(len(names)<=512,'provider root count exceeds existing observer limit')
        for name in names:
            if mode=='production' and name in ('action-ledger','claims'):
                directory(root/name);continue
            need(re.fullmatch(r'[0-9]{8}-[0-9]{6}-[0-9a-f]{32}',name),'unrecognized provider evidence member')
            run=root/name;directory(run);runs+=1;need(runs<=512,'combined provider run bound')
            path=run/'provider-in.jsonl'
            try:raw=read(path)
            except FileNotFoundError:
                absent(path);missing.append(str(path));continue
            need(not raw or raw.endswith(b'\n'),'partial provider input tail is not a complete absence proof')
            local=0
            for line in raw.splitlines(keepends=True):
                check();need(line.endswith(b'\n') and len(line)<=4*1024*1024,'bounded complete provider line required')
                frame=strict(line);need(type(frame) is dict,'provider frame object required');lines+=1
                need(lines<=65536,'provider frame count exceeded')
                if frame.get('kind')!='turn.start':continue
                turn=frame.get('turn');need(type(turn) is dict and type(turn.get('user_input')) is str,'turn.start user input required')
                local+=1;owner=sha(turn['user_input'].encode())
                if owner in wanted:matches.append({'path':str(path),'owner_request_sha256':owner,'line_sha256':sha(line)})
            scanned.append({'mode':mode,'path':str(path),'bytes':len(raw),'sha256':sha(raw),'turn_start_count':local})
    need(not matches,'a failed owner hash has a published provider turn.start')
    return {'scope':'all complete provider-in.jsonl files in the two fixed evidence roots',
        'provider_match_count':0,'matches':[],'run_count':runs,'frame_count':lines,
        'files':scanned,'missing_original_provider_input_paths':missing,
        'native_journal_hash_chain_claimed':False,'unrelated_file_contents_scanned':False}

def main():
    global START
    START=time.monotonic();error=None;result=None
    try:
        need(len(sys.argv)==1,'fixed two-attempt observer takes no arguments')
        need(os.getuid()==os.geteuid()==os.getgid()==os.getegid()==0,'actual Root credentials required')
        boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip();need(boot==BOOT,'actual boot changed')
        now=time.time_ns()//1000000;need(all(now>=x['lease_expires_unix_ms'] for x in ATTEMPTS),'both original leases must remain expired')
        root=BASE/'native-guard-boundaries-r10-r1';directory(root)
        head=read(ACTUAL08['path'],16384)
        need((len(head),sha(head))==(ACTUAL08['bytes'],ACTUAL08['sha256'])
             and FILES[ACTUAL08['path']]['metadata']==ACTUAL08['metadata'],'last actual native boundary original changed')
        for item in ATTEMPTS:
            absent(root/(item['nonce']+'.json'));absent(root/item['nonce'])
        selected=selected_state();provider=provider_starts()
        for path,row in list(FILES.items()):read(path,max(1,row['bytes']),root_owned=row['root_owned'])
        for path in list(DIRECTORIES):directory(path)
        for path in list(ABSENT):absent(path)
        need(selected_state()==selected,'current selected state changed across scoped observation')
        need(Path('/proc/sys/kernel/random/boot_id').read_text().strip()==BOOT,'boot changed across scoped observation');check()
        result={'schema':'hepta.native-guard.failed-prelaunch-current-observation.v1',
            'state':'TWO_FAILED_NONCES_UNPUBLISHED_SELECTED_ORIGINAL_UNCHANGED',
            'boot_id':BOOT,'attempts':list(ATTEMPTS),'last_real_native_boundary':ACTUAL08,
            'observed_unix_ms':now,'completed_unix_ms':time.time_ns()//1000000,
            'selected':selected,'android_user_zero_anchor':USER_ZERO_VIEW,'provider':provider,
            'files':FILES,'directories':DIRECTORIES,'explicit_absence':ABSENT,
            'full9_readset_canonical_recheck_complete':True,
            'read_total_bytes':READ_TOTAL,'elapsed_seconds':time.monotonic()-START,
            'phone_writes':0,'process_starts':0,'signals_sent':0,'socket_connections':0,'model_requests':0,
            'native_boundary_created':False,'failed_prelaunch_closed_here':False,
            'component_qualified':False,'business_qualified':False,'automatic_retry':False}
        raw=(json.dumps(result,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
        need(len(raw)<=MAX_OUTPUT,'complete scoped observation exceeds one MiB')
    except BaseException as exc:
        error={'type':type(exc).__name__,'detail':str(exc)[:1024]}
        raw=(json.dumps({'schema':'hepta.native-guard.failed-prelaunch-current-observation.v1',
            'state':'CURRENT_OBSERVATION_FAILED_OR_PARTIAL_RETAIN_ORIGINALS','boot_id':BOOT,'attempts':list(ATTEMPTS),
            'error':error,'read_total_bytes':READ_TOTAL,'elapsed_seconds':time.monotonic()-START,
            'phone_writes':0,'process_starts':0,'signals_sent':0,'failed_prelaunch_closed_here':False,
            'component_qualified':False,'automatic_retry':False},sort_keys=True,separators=(',',':'))+'\n').encode()
    sys.stdout.write(raw.decode());return 1 if error else 0

if __name__=='__main__':raise SystemExit(main())
