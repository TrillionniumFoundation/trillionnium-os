import hashlib
import io
import json
import lzma
import os
from pathlib import Path
import stat
import tarfile
import time

SOURCE = Path('/home/alex/codex-hepta-natural-root-r10-neg01-20261105-09-root-v150')
OUT = Path('/home/alex/razr60-local-model-v150/fixed19-external09-1ad3-readonly-evidence01')
META = ('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
MAX_SINGLE = 1024*1024
MAX_TOTAL = 8*1024*1024

def need(v, message):
    if not v:
        raise ValueError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def enc(value):
    return (json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()

def meta(value):
    return [getattr(value,key) for key in META]

def desc(path, raw):
    return {'path':str(path),'bytes':len(raw),'sha256':sha(raw)}

def snapshot():
    need(SOURCE.resolve(strict=True)==SOURCE,'canonical exact sender root required')
    directories = {}
    files = {}
    pending = [SOURCE]
    while pending:
        root = pending.pop()
        relative = root.relative_to(SOURCE).as_posix()
        s = root.lstat()
        need(stat.S_ISDIR(s.st_mode) and not root.is_symlink() and root.resolve(strict=True)==root,
             'single canonical original directory required')
        need(len(directories)<64 and len(root.relative_to(SOURCE).parts)<=8,'bounded sender directory set required')
        directories[relative] = {'path':str(root),'metadata':meta(s)}
        names = sorted(os.listdir(root))
        for name in names:
            path = root/name
            st = path.lstat()
            need(path.resolve(strict=True)==path,'no symlink or path alias in sender originals')
            if stat.S_ISDIR(st.st_mode):
                pending.append(path)
            else:
                need(stat.S_ISREG(st.st_mode) and st.st_nlink==1 and 0<=st.st_size<=MAX_SINGLE,
                     'bounded single-link regular sender original required')
                rel = path.relative_to(SOURCE).as_posix()
                need(rel not in files and len(files)<256,'bounded unique sender file set required')
                files[rel] = {'path':str(path),'relative_path':rel,'bytes':st.st_size,'metadata':meta(st)}
        need(meta(root.lstat())==meta(s),'original sender directory changed during enumeration')
    need(files and sum(row['bytes'] for row in files.values())<=MAX_TOTAL,'bounded complete sender originals required')
    return directories,files

started = time.time_ns()
directories,rows = snapshot()
blobs = {}
for name,row in sorted(rows.items()):
    path = Path(row['path'])
    fd = os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        need(meta(os.fstat(fd))==row['metadata'],'original sender identity changed before open')
        with os.fdopen(fd,'rb',closefd=False) as stream:
            raw = stream.read(row['bytes']+1)
        need(len(raw)==row['bytes'] and meta(os.fstat(fd))==row['metadata']==meta(path.lstat()),
             'sender original changed during fd read')
    finally:
        os.close(fd)
    row['sha256'] = sha(raw)
    blobs['sender-originals/'+name] = raw
after_dirs,after_rows = snapshot()
need(after_dirs==directories and after_rows=={n:{k:v for k,v in r.items() if k!='sha256'} for n,r in rows.items()},
     'sender closed file set or full metadata changed')
inventory = {'schema':'hepta.fixed19.readonly-original-sender-inventory.v2',
    'state':'EXACT_CLOSED_SENDER_ORIGINAL_SET_READ_WITH_FULL9_BOOKENDS',
    'label':'root-r10-neg01-20261105-09','source':str(SOURCE),
    'started_unix_ns':started,'finished_unix_ns':time.time_ns(),
    'directories':[dict(relative_path=n,**r) for n,r in sorted(directories.items())],
    'files':[row for _,row in sorted(rows.items())],
    'source_file_count':len(rows),'source_bytes':sum(r['bytes'] for r in rows.values()),
    'closed_set_bookend_equal':True,'all_fd_and_named_full9_equal':True,
    'send_named_records_present':sorted(n for n in rows if n.startswith('SEND')),
    'phone_calls':0,'signals_sent':0,'original_files_changed':False,'case_pass':False}
inventory_raw = enc(inventory)
blobs['P4-SENDER-INVENTORY.original.json'] = inventory_raw
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w',format=tarfile.USTAR_FORMAT) as archive:
    for name,raw in sorted(blobs.items()):
        info = tarfile.TarInfo(name)
        info.size = len(raw);info.mode = 0o600;info.uid = info.gid = 0;info.mtime = 0
        archive.addfile(info,io.BytesIO(raw))
plain = buffer.getvalue()
need(len(plain)<=16*1024*1024,'sender original tar exceeds existing bounded evidence size')
xz = lzma.compress(plain,format=lzma.FORMAT_XZ,check=lzma.CHECK_CRC64,preset=6)
need(lzma.decompress(xz)==plain,'lossless sender tar mirror differs')
with tarfile.open(fileobj=io.BytesIO(plain),mode='r:') as archive:
    verified = {}
    for item in archive:
        need(item.isreg() and item.name in blobs and item.name not in verified,'exact regular tar membership required')
        raw = archive.extractfile(item).read(item.size+1)
        need(raw==blobs[item.name],'tar member bytes differ')
        verified[item.name] = raw
need(verified==blobs,'sender archive omitted originals')
final_dirs,final_rows = snapshot()
need(final_dirs==directories and final_rows==after_rows,'sender source changed during archive encoding')
need(OUT.parent.resolve(strict=True)==OUT.parent and not OUT.exists() and not OUT.is_symlink(),
     'new independent evidence namespace required')
os.mkdir(OUT,0o700)

def syncdir(path):
    fd = os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

def put(name,raw):
    path = OUT/name
    fd = os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb') as stream:
        stream.write(raw);stream.flush();os.fsync(stream.fileno())
    need(path.read_bytes()==raw,'new evidence readback differs')
    return desc(path,raw)

source_row = put('COLLECTOR.original.py',COLLECTOR_SOURCE)
inventory_row = put('P4-SENDER-INVENTORY.original.json',inventory_raw)
archive_row = put('SENDER-ORIGINALS.tar.xz',xz)
manifest = {'schema':'hepta.fixed19.readonly-originals-archive.v2',
    'state':'FAILED_CASE_SENDER_ORIGINALS_RETAINED_WITH_LOSSLESS_TAR_XZ',
    'collector_source':source_row,'source':str(SOURCE),'inventory':inventory_row,
    'source_file_count':len(rows),'source_bytes':inventory['source_bytes'],
    'archive':archive_row,'tar_plaintext':{'bytes':len(plain),'sha256':sha(plain)},
    'files':[desc(name,raw) for name,raw in sorted(blobs.items())],
    'all_original_full9_and_closed_set_rechecked':True,'archive_roundtrip_verified':True,
    'phone_calls':0,'signals_sent':0,'original_files_changed':False,'case_pass':False,
    'original_parent_join_proven':False,'original_capture_eof_repaired':False}
manifest_row = put('MANIFEST.json',enc(manifest))
syncdir(OUT);syncdir(OUT.parent)
result = {'schema':'hepta.fixed19.external09-readonly-sender-collection.v1',
    'state':manifest['state'],'source':str(SOURCE),'collector_source':source_row,
    'inventory':inventory_row,'manifest':manifest_row,'archive':archive_row,
    'source_file_count':len(rows),'source_bytes':inventory['source_bytes'],
    'tar_plaintext':manifest['tar_plaintext'],'source_file_hashes_verified':True,
    'phone_calls':0,'signals_sent':0,'case_pass':False,
    'original_parent_join_proven':False,'original_capture_eof_repaired':False}
put('RESULT.json',enc(result));syncdir(OUT)
print(enc(result).decode(),end='')
