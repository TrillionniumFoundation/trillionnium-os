#!/usr/bin/env python3
"""Lossless local verification of already read host-only evidence; never executes it."""
import argparse
import base64
import hashlib
import io
import json
import lzma
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent

def need(value, reason):
    if not value:
        raise ValueError(reason)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def enc(value):
    return (json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()

def desc(path,raw):
    return {'path':str(path),'bytes':len(raw),'sha256':sha(raw)}

def put(path,raw):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)
    need(path.read_bytes()==raw,'local write differs')

def chunked(name, expected):
    paths=sorted((HERE/'downloads'/name).glob('CONTROLLER-CHUNK*.original.json'))
    need(paths,'controller binary read originals absent')
    version=None;offset=0;chunks=[];rows=[]
    for path in paths:
        envelope=json.loads(path.read_bytes());request=envelope['request'];result=envelope['result']
        need(result.get('isError') is not True,'controller binary read reported error')
        value=json.loads(result['content'][0]['text'])
        need(value['path']==expected['path'] and value['size']==expected['bytes']
             and value['offset']==offset==request['offset'],'chunk source/offset differs')
        if version is None:version=value['version']
        else:need(request['expected_version']==value['version']==version,'chunk source version changed')
        raw=base64.b64decode(value['data_base64'],validate=True)
        need(sha(raw)==value['chunk_sha256'] and value['next_offset']==offset+len(raw),'chunk hash/next offset differs')
        rows.append({'receipt':desc(path,path.read_bytes()),'offset':offset,'bytes':len(raw),'sha256':sha(raw)})
        chunks.append(raw);offset=value['next_offset']
        need(value['eof']==(offset==expected['bytes']),'unexpected binary EOF')
    raw=b''.join(chunks)
    need(len(raw)==expected['bytes'] and sha(raw)==expected['sha256'],'whole downloaded original differs')
    return raw,{'version':version,'chunks':rows,'whole_file_verified':True}

def tar_xz(raw, plain_pin):
    decoder=lzma.LZMADecompressor(format=lzma.FORMAT_XZ,memlimit=128*1024*1024)
    plain=decoder.decompress(raw,max_length=16*1024*1024+1)
    need(decoder.eof and not decoder.unused_data and len(plain)<=16*1024*1024,'bounded single xz required')
    need({'bytes':len(plain),'sha256':sha(plain)}==plain_pin,'original tar plaintext differs')
    files={}
    with tarfile.open(fileobj=io.BytesIO(plain),mode='r:') as archive:
        for item in archive:
            path=Path(item.name)
            need(item.isreg() and not item.pax_headers and not path.is_absolute() and str(path)==item.name
                 and '..' not in path.parts and item.name not in files and len(files)<512,
                 'strict unique regular tar member required')
            need(item.mode==0o600 and item.uid==item.gid==0 and item.mtime==0 and 0<=item.size<=8*1024*1024,
                 'original tar metadata differs')
            body=archive.extractfile(item).read(item.size+1)
            need(len(body)==item.size,'short tar body')
            files[item.name]=body
    return files

def match_files(files, rows):
    need(type(rows) is list and len(rows)==len({r['path'] for r in rows})==len(files),'closed tar set differs')
    need(set(files)=={r['path'] for r in rows},'tar file membership differs')
    for row in rows:
        need(desc(row['path'],files[row['path']])==row,'tar member hash differs: '+row['path'])

def main():
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['mac-evidence','p4-sender','p4-manifest','mac-component'])
    mode=parser.parse_args().mode
    mac=json.loads((HERE/'mac-COLLECTION-RESULT.original.json').read_bytes())
    p4=json.loads((HERE/'p4-COLLECTION-RESULT.original.json').read_bytes())
    if mode=='mac-evidence':
        raw,download=chunked(mode,mac['evidence_archive'])
        files=tar_xz(raw,mac['evidence_tar_plaintext']);match_files(files,mac['evidence_files'])
        need(files['COLLECTOR.original.py']==(HERE/'source/collect_mac_originals_and_absence.py').read_bytes(),
             'executed collector source differs')
        need(len(files['SENDER-ACTOR.original.py'])==82909 and sha(files['SENDER-ACTOR.original.py'])==
             '34c1534d5985bd643c74361a5009b980e5684d6f1373b2e34eed7fcbde283e04','fixed actor differs')
        observation=json.loads(files['MAC-SENDER-ABSENCE.original.json'])
        for index,row in enumerate(observation['observations']):
            need(row['index']==index and row['ps_returncode']==0,'actual ps observation failed')
            body=files['PS-'+str(index)+'.stdout.original']
            need(len(body)==row['stdout']['bytes'] and sha(body)==row['stdout']['sha256'],'ps stdout differs')
            matches=[]
            for line in body.decode().splitlines():
                fields=line.split(None,9);need(len(fields)==10,'ps row parsing differs')
                if fields[0]=='80237' or fields[2]=='80237' or 'root-r10-neg01-20261105-09' in fields[9]:matches.append(line)
            need(matches==row['owned_pid_or_group_or_exact_label_rows']==[] and row['matching_process_count']==0,
                 'original pid/group/label still appears in later ps observation')
        need(len(observation['observations'])==2
             and observation['observations'][0]['finished_unix_ns']<observation['observations'][1]['started_unix_ns'],
             'two distinct ordered later observations required')
        need(observation['original_parent_join_proven'] is False and observation['original_capture_eof_repaired'] is False,
             'later absence cannot retrofit parent join/EOF')
        put(HERE/'MAC-ORIGINALS-AND-OBSERVATIONS.tar.xz',raw)
        for name,body in files.items():put(HERE/'mac-originals'/name,body)
        detail={'regular_members':len(files),'original_actor_sha256':sha(files['SENDER-ACTOR.original.py']),
                'both_later_process_observations_independently_reparsed_absent':True,
                'original_parent_join_proven':False,'original_capture_eof_repaired':False}
    elif mode=='p4-sender':
        raw,download=chunked(mode,p4['archive']);files=tar_xz(raw,p4['tar_plaintext'])
        inventory_raw=files['P4-SENDER-INVENTORY.original.json']
        need(len(inventory_raw)==p4['inventory']['bytes'] and sha(inventory_raw)==p4['inventory']['sha256'],'inventory pin differs')
        inventory=json.loads(inventory_raw)
        need(inventory['source']==p4['source'] and inventory['source_file_count']==len(inventory['files'])==170
             and inventory['source_bytes']==sum(r['bytes'] for r in inventory['files'])==5366983,'sender closed inventory differs')
        expected=[desc('P4-SENDER-INVENTORY.original.json',inventory_raw)]
        for row in inventory['files']:
            rel=Path(row['relative_path']);need(not rel.is_absolute() and '..' not in rel.parts
                and str(Path(p4['source'])/rel)==row['path'],'canonical sender relative path differs')
            need(len(row['metadata'])==9 and row['metadata'][5]==1 and row['metadata'][6]==row['bytes'],
                 'sender original full9 metadata differs')
            expected.append({'path':'sender-originals/'+row['relative_path'],'bytes':row['bytes'],'sha256':row['sha256']})
        match_files(files,expected)
        need(inventory['closed_set_bookend_equal'] is True and inventory['all_fd_and_named_full9_equal'] is True,
             'complete sender source bookends missing')
        put(HERE/'SENDER-ORIGINALS.tar.xz',raw)
        for name,body in files.items():put(HERE/'p4-originals'/name,body)
        detail={'regular_members':len(files),'sender_originals':170,'sender_original_bytes':5366983,
                'inventory_full9_and_member_hashes_verified':True}
    elif mode=='p4-manifest':
        raw,download=chunked(mode,p4['manifest']);value=json.loads(raw)
        need(value['archive']==p4['archive'] and value['inventory']==p4['inventory']
             and value['source_file_count']==p4['source_file_count'],'archive manifest linkage differs')
        archive=(HERE/'SENDER-ORIGINALS.tar.xz').read_bytes();files=tar_xz(archive,value['tar_plaintext']);match_files(files,value['files'])
        put(HERE/'P4-SENDER-ARCHIVE-MANIFEST.original.json',raw)
        detail={'manifest_members':len(value['files']),'archive_manifest_and_all_member_hashes_verified':True}
    else:
        raw,download=chunked(mode,mac['component_tar_xz'])
        mirror=json.loads((HERE/'mac-originals/COMPONENT-XZ-MIRROR-RESULT.original.json').read_bytes())
        need(mirror['source_archive']==mac['source_component_archive'] and mirror['archive']==mac['component_tar_xz'],
             'original component gzip and lossless tar-xz source binding differs')
        files=tar_xz(raw,mirror['tar_plaintext']);match_files(files,mirror['files'])
        need(len(files)==56 and files['LEASE.json']==(HERE/'mac-originals/LEASE.original.json').read_bytes(),
             'exact56 or actual lease differs')
        prepared=json.loads((HERE.parent/'external09-small-originals/material/PREPARED.json').read_bytes())
        lease=json.loads(files['LEASE.json']);need(desc('LEASE.json',files['LEASE.json'])==dict(path='LEASE.json',**prepared['lease']),
             'actual prepared lease pin differs')
        need(lease['nonce']==prepared['nonce']=='7c79195945d64e569a191166ac122a08'
             and sha(files['owner-request.txt'])==prepared['owner_request_sha256'],'lease and owner request differ')
        manifest=json.loads(files['package/MANIFEST.json'])
        need(len(files['package/MANIFEST.json'])==16808 and sha(files['package/MANIFEST.json'])==
             '67dc40470b8ecb1e10cb57f8953a3d0b6db309b45079216eb24cd65f0760107c' and len(manifest['files'])==32,
             'canonical actual runtime32 differs')
        for row in manifest['files']:
            need(desc(row['path'],files['package/'+row['path']])==row,'complete runtime member differs')
        put(HERE/'component-inputs.original.tar.xz',raw)
        for name,body in files.items():put(HERE/'component-originals'/name,body)
        detail={'component_regular_members':56,'runtime_members':32,'lease_original_sha256':sha(files['LEASE.json']),
                'source_gzip_original_retained_on_mac':mirror['source_archive'],
                'local_xz_preserves_exact_decompressed_original_tar_bytes':True,
                'original_compressed_gzip_bytes_not_claimed_as_locally_downloaded':True}
    result={'schema':'hepta.fixed19.external09-local-original-download-verification.v1',
            'state':'EXACT_ORIGINAL_DOWNLOAD_AND_ARCHIVE_MEMBERS_VERIFIED','mode':mode,
            'download':download,**detail,'phone_calls':0,'target_sources_executed':0,'case_pass':False}
    result_raw=enc(result);path=HERE/'validation'/(mode+'.json');put(path,result_raw)
    print(json.dumps({'report':desc(path,result_raw),'mode':mode,**detail},sort_keys=True))

if __name__=='__main__':main()
