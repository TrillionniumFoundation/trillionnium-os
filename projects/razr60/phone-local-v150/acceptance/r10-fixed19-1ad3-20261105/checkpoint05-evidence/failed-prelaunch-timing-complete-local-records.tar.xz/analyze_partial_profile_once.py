#!/usr/bin/env python3
"""Read one retained diagnostic JSON. No runtime import, probe, or benchmark."""
from pathlib import Path
import hashlib
import json

ROOT = Path('/workspace/scratch/1ad3d6f55439')
PATH = ROOT/'actual_neg01_1ad3_01/reconciliation/profile-read01/originals/PHONE-STDOUT.original'
OUT = ROOT/'neg01_prelaunch_timing_review/PARTIAL-PROFILE-ATTRIBUTION.json'
raw = PATH.read_bytes()
assert len(raw) == 491719
assert hashlib.sha256(raw).hexdigest() == 'efc845a1cc03b699997a70c8c71a2938ce5b28b9f8cc7c5f135027094f10b34b'
value = json.loads(raw)
profile = value['profile']
assert profile['entry_columns'] == ['entry_id','description_id','calls','recursive_calls',
    'primitive_calls','self_seconds','cumulative_seconds','callees']
assert profile['callee_columns'] == ['entry_id_if_same_object','description_id','calls',
    'recursive_calls','primitive_calls','self_seconds','cumulative_seconds']
assert len(profile['entries']) == profile['entry_count'] == 1676
assert sum(len(row[7]) for row in profile['entries']) == profile['edge_count'] == 6127
descriptions = profile['descriptions']
entries = profile['entries']
assert len({row[0] for row in entries}) == len(entries)


def retained(row):
    result = dict(zip(profile['entry_columns'][:-1], row[:-1]))
    result['description'] = dict(zip(profile['description_columns'], descriptions[row[1]]))
    result['callees'] = [dict(zip(profile['callee_columns'], edge)) for edge in row[7]]
    return result


target_names = {'verify_retired','verify_current','chain_originals','inventory_value',
                'preserve_non_native_private','closed_boundary_originals'}
selected = [row for row in entries if descriptions[row[1]][3] in target_names]
compile_rows = [row for row in entries if descriptions[row[1]][3] == '<built-in method builtins.compile>']
report = {
    'schema':'hepta.root.neg01.partial-profile-attribution.v1',
    'state':'RETAINED_PARTIAL_DIAGNOSTIC_ONLY_NO_GLOBAL_VERIFICATION',
    'source_original':dict(path=str(PATH), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()),
    'diagnostic_state':value['state'], 'failure':value['failure'],
    'original_verifier_returned':value['original_verifier_returned'],
    'original_verification_complete':value['original_verification_complete'],
    'reported_original_verify_retired_calls':value['original_verify_retired_calls'],
    'reported_zero_is_not_proof_of_no_entry':True,
    'explicit_nested_entry':retained(next(row for row in entries if row[0] == 275)),
    'timing':{key:value[key] for key in ('profile_wall_seconds','profile_cpu_seconds','total_wall_seconds')},
    'diagnostic_deadline':value['diagnostic_deadline'],
    'cleanup':value['owned_verifier_lock_cleanup'],
    'entries_preserved':1676,'edges_preserved':6127,
    'top_exclusive_self_entries':[retained(row) for row in sorted(entries,key=lambda row:row[5],reverse=True)[:18]],
    'selected_target_codeobject_entries':[retained(row) for row in selected],
    'compile_entries':[retained(row) for row in compile_rows],
    'findings':[
        'The original verification did enter late.verify_current: entry275 records one call and 180.000052536 cumulative seconds. The enclosing original_verify_retired_calls=0 is incomplete profiler accounting, not absence of execution.',
        'Recorded exclusive work is concentrated in pathlib ancestry construction, equality and collections membership: millions of Path parent objects and comparisons. This supports the local source-level ancestry finding but is not an uninstrumented production budget.',
        'Current R8 inventory_value entry385 records four calls and 20.168585670 cumulative seconds. Multiple separate immutable R7 and R6 code objects also performed inventory_value and preserve_non_native_private work. The reviewed single current-reader expression cannot remove those unchanged historical computations.',
        'The trace callback observed148936704 Python call events and145446 clock checks. Its own observer cost is inseparable from this instrumented run; no reliable production speedup or uninstrumented global duration is inferred.',
        'The original verifier did not return. Global inventory, group, endpoint or late terminal completeness is not established by this diagnostic. No current-case or failed-prelaunch closure credit is granted.',
        'Entry277 cumulative268.464910314 exceeds the180s outer interval; this retained interrupted nested accounting illustrates why cumulative values must not be summed or treated as exclusive elapsed segments.'
    ],
    'interpretation_limits':{
        'same_description_entries_merged':False,
        'cumulative_seconds_summed':False,
        'absent_or_zero_entry_claimed_not_entered':False,
        'observer_overhead_removed_or_estimated':False,
        'phone_duration_predicted':False,
        'new_profile_or_benchmark_run':False,
        'target_runtime_imported_or_executed':False,
        'global_state_verified':False,
        'physical_case_passed':False,
        'historical_references_changed':False,
        'production_deadlines_changed':False
    }
}
out = (json.dumps(report, sort_keys=True, indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()
with OUT.open('xb') as stream:
    stream.write(out)
assert PATH.read_bytes() == raw
print(json.dumps(dict(path=str(OUT),bytes=len(out),sha256=hashlib.sha256(out).hexdigest()),sort_keys=True))
