#!/usr/bin/env python3
"""Run one pinned host regression once, preserving command, streams and outcome."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT / "source/projects/razr60/phone-local-v150/acceptance/r10-fixed19-1ad3-20261105/followthrough-20261106-fc33/neg10-14-final-source-summary/references/native-v3"
CASES = {
    "selected-guards-01": ("test_selected_neg10_neg14_v3.py", []),
    "shared-business-01": ("test_shared_business_admission_v3.py", []),
    "native-require-actual-01": ("test_native_streams_v3.py", ["--require-actual"]),
    "native-public-fixtures-01": ("test_native_streams_v3.py", []),
}


def pin(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def write_new(path, raw):
    with path.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def main():
    os.umask(0o077)
    label = sys.argv[1]
    script, flags = CASES[label]
    run = ROOT / "runs" / label
    run.mkdir(parents=True)
    output = run / "output"
    command = [sys.executable, "-I", "-B", str(PACKAGE / script),
               "--package-root", str(PACKAGE), "--out", str(output), *flags]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    intent = {"schema": "razr60.cloud-isolated-regression-intent.v1", "label": label,
              "commit": "ca3f26100c57579bcb740488e4a7f9ec8b912e4d", "argv": command,
              "cwd": str(ROOT), "started_at_utc": started,
              "script": pin(PACKAGE / script), "candidate_pins": pin(PACKAGE / "CANDIDATE-PINS.json"),
              "timeout_seconds": 70, "automatic_retry": False,
              "scope": "public pinned host fixtures; actual archived originals are required only when explicitly flagged",
              "physical_task_credit": 0}
    write_new(run / "INTENT.json", (json.dumps(intent, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode())
    begin = time.monotonic()
    timed_out = False
    with (run / "stdout.original.txt").open("xb") as stdout, (run / "stderr.original.txt").open("xb") as stderr:
        process = subprocess.Popen(command, cwd=ROOT, stdin=subprocess.DEVNULL,
                                   stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            returncode = process.wait(timeout=70)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                returncode = process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                returncode = process.wait(timeout=5)
        stdout.flush()
        stderr.flush()
        os.fsync(stdout.fileno())
        os.fsync(stderr.fileno())
    result_file = output / "RESULT.json"
    result = json.loads(result_file.read_bytes()) if result_file.is_file() else None
    record = {"schema": "razr60.cloud-isolated-regression-run.v1", "label": label,
              "argv": command, "cwd": str(ROOT), "started_at_utc": started,
              "finished_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "elapsed_seconds": time.monotonic() - begin, "exit_code": returncode,
              "timed_out": timed_out, "original_child_waited": True, "automatic_retry": False,
              "stdout": pin(run / "stdout.original.txt"), "stderr": pin(run / "stderr.original.txt"),
              "result": pin(result_file) if result is not None else None,
              "reported_state": (result.get("state") or result.get("status")) if result else None,
              "fatal_error": result.get("fatal_error") if result else None,
              "actual_original_checks": result.get("original_actual_checks") if result else None,
              "phone_calls": result.get("phone_calls") if result else None,
              "model_requests": result.get("model_requests") if result else None,
              "native_dispatches": result.get("native_dispatches") if result else None,
              "physical_task_credit": 0}
    write_new(run / "RUN.json", (json.dumps(record, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode())
    print(json.dumps(record, ensure_ascii=False, sort_keys=True))
    return returncode


if __name__ == "__main__":
    sys.exit(main())
