# synthetic unused runtime fixture 3
