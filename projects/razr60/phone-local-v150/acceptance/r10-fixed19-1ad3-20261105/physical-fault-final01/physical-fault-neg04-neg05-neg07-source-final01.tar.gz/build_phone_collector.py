#!/usr/bin/env python3
"""Reproduce the separate fault collector; preserve the CPU collector original."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def replace_once(raw, old, new):
    assert raw.count(old) == 1, old[:100]
    return raw.replace(old, new)


def derive():
    original = (ROOT/'reference/capture-negative-phone-r7.py').read_text()
    raw = original
    tree = ast.parse(raw)
    node = next(n for n in tree.body if isinstance(n, ast.Assign)
                and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'FINAL_DEPENDENCIES')
    lines = raw.splitlines(keepends=True)
    lines[node.lineno-1:node.end_lineno] = ['FINAL_DEPENDENCIES = None\n']
    raw = ''.join(lines)
    raw = raw.replace('hepta.cpu-cancel.', 'hepta.physical-fault.')
    raw = raw.replace('ui_package_sha256', 'fault_package_sha256')
    raw = raw.replace('cpu_verifier_sha256', 'fault_verifier_sha256')
    raw = raw.replace('cpu_eligibility_assessed', 'fault_eligibility_assessed')
    raw = raw.replace("'negative-original-captures-r10-r1'", "'fault-original-captures-r10-r1'")
    raw = replace_once(raw, "bound['case_id'] in ('NEG-08','NEG-09'),'only_NEG08_or_NEG09_originals'",
                       "bound['case_id'] in ('NEG-04','NEG-05','NEG-07'),'only_NEG04_NEG05_NEG07_originals'")
    raw = replace_once(raw, " 'runtime_binding','runtime','task_template_sha256','app_scope_sha256'}",
                       " 'runtime_binding','runtime','task_template_sha256','app_scope_sha256',\n"
                       " 'watch_plan_sha256','watch_source_sha256'}")
    raw = replace_once(raw, "'operator_plan_sha256','operator_package_sha256','task_template_sha256','app_scope_sha256'):",
                       "'operator_plan_sha256','operator_package_sha256','task_template_sha256','app_scope_sha256',\n"
                       "             'watch_plan_sha256','watch_source_sha256'):")
    extra = '''def capture_fault_originals(bound):
 capture(BASE/'fault-source-bundles-r10-r1'/bound['nonce']/'OPERATOR-BUNDLE.original.json',
      'fault-bundle/OPERATOR-BUNDLE.original.json',limit=262144)
 root=BASE/'fault-watch-r10-r1'/bound['owner_request_sha256']
 actor=BASE/'fault-injections-r10-r1'/bound['owner_request_sha256']
 tree(root,'fault-watch');tree(actor,'fault-actor')
 required={'fault-watch/PLAN.original.json','fault-watch/SOURCE.original.py',
   'fault-watch/ARMED.json','fault-watch/ACTOR-PLAN.original.json','fault-watch/RESULT.json',
   'fault-actor/INTENT.json','fault-actor/PRE-SIGNAL.json','fault-actor/RESULT.json'}
 need(required<=set(RAW),'complete_fault_actor_and_watch_originals_required')
 need(sha(RAW['fault-watch/PLAN.original.json'])==bound['watch_plan_sha256'] and
      sha(RAW['fault-watch/SOURCE.original.py'])==bound['watch_source_sha256'] and
      sha(RAW['fault-watch/ACTOR-PLAN.original.json'])==bound['operator_plan_sha256'],
      'actual_fault_watch_and_actor_source_plan_pins')
 ap=strict(RAW['fault-watch/ACTOR-PLAN.original.json'])
 result=strict(RAW['fault-watch/RESULT.json']);act=strict(RAW['fault-actor/RESULT.json'])
 need(ap['case_id']==bound['case_id'] and ap['nonce']==bound['nonce'] and
      ap['scope']==bound['sender_scope'] and ap['run']==bound['sender_run'] and
      ap['owner_request_sha256']==bound['owner_request_sha256'] and
      ap['operation_id']==bound['operator_label'],'actual_fault_actor_plan_binding')
 need(result['state']=='ONE_FAULT_AND_FINAL_ORIGINAL_OBSERVATION_RETAINED' and
      result['actor_plan_sha256']==bound['operator_plan_sha256'] and
      result['watch_plan_sha256']==bound['watch_plan_sha256'] and
      result['watch_source_sha256']==bound['watch_source_sha256'] and
      result['case_id']==bound['case_id'] and result['scope']==bound['sender_scope'] and
      result['automatic_retry'] is False and result['physical_case_pass'] is False and
      act['state']=='ONE_PIDFD_ACTION_RETURNED','actual_fault_actor_not_successfully_joined')
 need('FAILURE.json' not in {Path(k).name for k in RAW if k.startswith(('fault-watch/','fault-actor/'))},
      'failed_fault_attempt_cannot_close')
 if bound['case_id']=='NEG-07':
  need('fault-watch/PRE-LATE-FENCE.json' in RAW and 'fault-watch/PRE-LATE-DURABILITY.json' in RAW and 'fault-watch/POST-LATE-FENCE.json' in RAW and
       'fault-watch/LATE-RECEIPT.original.json' in RAW,'actual_NEG07_live_before_late_fence_missing')
 R['fault_watch_plan_sha256']=bound['watch_plan_sha256']
 R['fault_watch_source_sha256']=bound['watch_source_sha256']
 R['bindings']['complete_original_fault_actor_and_watch']=True

'''
    raw = replace_once(raw, 'def capture_bound(bound):', extra+'def capture_bound(bound):')
    raw = replace_once(raw, ' capture_model_originals(bound)\n',
                       ' capture_fault_originals(bound)\n capture_model_originals(bound)\n')
    raw = replace_once(raw, "    'boot_Enforcing_policy_bookends_equal'}",
                       "    'boot_Enforcing_policy_bookends_equal','complete_original_fault_actor_and_watch'}")
    raw = raw.replace('Bounded Root read-only capture of an existing NEG08/09 original turn.',
                      'Bounded Root read-only capture of an existing NEG04/05/07 original turn.')
    raw = raw.replace('This separate entry does not broaden the frozen positive-case collector.',
                      'This separate entry does not broaden the positive or CPU cancellation collector.')
    compile(raw, 'capture_fault_phone.py', 'exec')
    (ROOT/'source/capture_fault_phone.py').write_text(raw)
    diff=''.join(difflib.unified_diff(original.splitlines(True),raw.splitlines(True),
        fromfile='capture-negative-phone-r7.py',tofile='capture_fault_phone.py'))
    (ROOT/'validation/capture_fault_phone.patch').write_text(diff)
    print(json.dumps({'bytes':len(raw.encode()),'sha256':hashlib.sha256(raw.encode()).hexdigest(),
                      'phone_calls':0,'final_dependencies_frozen':False},sort_keys=True))


if __name__=='__main__':
    derive()
