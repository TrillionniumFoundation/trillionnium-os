#!/usr/bin/env python3
"""Build a separate read-only sender archive using exact reviewed fd/census code."""
import ast
import hashlib
from pathlib import Path

R=Path(__file__).resolve().parent
old=(R/'reference/capture-p4-cancel-r7.py').read_text()
tree=ast.parse(old)
names={'need','sha','encoded','strict','metadata','canonical','under','parent_fd','exact3',
       'read_regular','observe_absence','new_directory','put','Capture','write_retained','archive'}
parts=[ast.get_source_segment(old,n) for n in tree.body
       if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
assert len(parts)==len(names)
header='''#!/usr/bin/env python3
"""Read-only complete P4 sender census for physical NEG04/05/07; no phone call."""
import argparse,base64,errno,gzip,hashlib,io,json,os,re,stat,sys,tarfile,time
from pathlib import Path
FINAL_DEPENDENCIES=None
P4='/home/alex/razr60-local-model-v150'
INPUT_BASE=P4+'/fault-p4-capture-inputs-r1'
OUTPUT_BASE=P4+'/fault-p4-original-captures-r1'
META=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
MAX_FILE=16*1024*1024
MAX_TOTAL=64*1024*1024
MAX_FILES=2048
MAX_DIRECTORY_FILES=1024
MAX_SECONDS=60.0
O_DIRECTORY=os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
'''
tail='''
def final_dependencies():
    need(type(FINAL_DEPENDENCIES) is dict and set(FINAL_DEPENDENCIES)=={'sender_sha256'} and
         FINAL_DEPENDENCIES['sender_sha256']=='5ab04019e94adb989e9909ae3a9aa10db0689de62821ec549db8beb3ec4d0281',
         'future_reviewed_sender_dependency_is_unfrozen')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--plan');p.add_argument('--plan-sha256');p.add_argument('--self-sha256')
    p.add_argument('--execute-read-once',action='store_true');args=p.parse_args()
    if not args.execute_read_once:
        print(encoded({'state':'SOURCE_PREVIEW_NO_PRIVATE_READ','phone_calls':0,'process_starts':0,
            'physical_case_pass':False,'final_dependencies_frozen':FINAL_DEPENDENCIES is not None}).decode(),end='')
        return 0
    final_dependencies()
    c=Capture();selfrow=c.file(os.path.abspath(__file__),'SOURCE.original.py',cap=65536)
    need(selfrow['sha256']==args.self_sha256,'actual_P4_capture_source_differs')
    row=c.file(args.plan,'PLAN.original.json',cap=65536)
    need(row['sha256']==args.plan_sha256,'actual_P4_capture_plan_differs')
    plan=strict(c.retained['PLAN.original.json'])
    need(type(plan) is dict and set(plan)=={'schema','case_id','nonce','sender_label','owner_request_sha256',
        'scope','out'} and plan['schema']=='hepta.physical-fault.p4-sender-capture-plan.v1' and
        plan['case_id'] in ('NEG-04','NEG-05','NEG-07') and re.fullmatch('[0-9a-f]{32}',plan['nonce']) and
        re.fullmatch('[a-z0-9][a-z0-9-]{5,69}',plan['sender_label']) and
        re.fullmatch('[0-9a-f]{64}',plan['owner_request_sha256']),'actual_fixed_fault_capture_plan')
    need(args.plan==INPUT_BASE+'/'+plan['nonce']+'/PLAN.json' and
         plan['out']==OUTPUT_BASE+'/'+plan['nonce'],'exact_new_P4_capture_namespace')
    out=plan['out'];new_directory(out)
    intent=put(out+'/INTENT.json',encoded({'schema':'hepta.physical-fault.p4-capture-intent.v1',
        'source':selfrow,'plan':row,'case_id':plan['case_id'],'maximum_capture_attempts':1,
        'phone_calls':0,'automatic_retry':False}))
    written=False
    try:
        source='/home/alex/codex-hepta-natural-'+plan['sender_label']+'-root-v150'
        directory,rows,absent=c.directory(source,'sender')
        need(directory is not None and absent is None,'actual_complete_sender_directory_required')
        required={'SEND.once.json','SEND-NATIVE-LATENCY.json','DRAFT-RESTORE-RESULT.json'}
        # Draft receipts are validated by the independent closer. Different
        # reviewed sender revisions may name the final receipt differently;
        # no member is omitted from this complete directory census.
        need({'SEND.once.json','SEND-NATIVE-LATENCY.json'}<=set(rows) and
             'ACTOR-FAILURE.json' not in rows,'actual_sender_did_not_finish_safely')
        once=strict(c.retained['sender/SEND.once.json'])
        need(once.get('prompt_sha256')==plan['owner_request_sha256'] and
             type(once.get('prompt')) is str and sha(once['prompt'].encode())==plan['owner_request_sha256'],
             'actual_sender_owner_binding')
        latency=strict(c.retained['sender/SEND-NATIVE-LATENCY.json'])
        need(latency.get('scope')==plan['scope'] and latency.get('owner_request_utf8_sha256')==
             plan['owner_request_sha256'],'actual_sender_scope_binding')
        c.recheck()
        report={'schema':'hepta.physical-fault.p4-sender-original-capture.v1',
            'state':'COMPLETE_P4_SENDER_ORIGINALS_CAPTURED_UNQUALIFIED','source':selfrow,'plan':row,
            'intent':intent,'case_id':plan['case_id'],'nonce':plan['nonce'],
            'sender_label':plan['sender_label'],'scope':plan['scope'],
            'owner_request_sha256':plan['owner_request_sha256'],
            'sender_directory':directory,'sender_originals':rows,
            'original_file_count':len(c.originals),'original_raw_bytes':c.total,
            'retained_member_count':len(c.retained),'all_original_full9_and_bytes_rechecked':True,
            'complete_directory_census_bookends_equal':True,'phone_calls':0,'signals':0,
            'physical_case_pass':False,'automatic_retry':False}
        body=encoded(report);need(len(body)<=4*1024*1024,'P4_capture_report_bound')
        written=True;write_retained(out,c.retained);c.recheck()
        capture=put(out+'/CAPTURE.original.json',body)
        packed=archive(out,c.retained,body,c.clock);c.recheck()
        result={'schema':'hepta.physical-fault.p4-capture-result.v1','state':report['state'],
            'capture':capture,'archive':packed,'archive_member_count':len(c.retained)+1,
            'originals_rechecked_after_archive':True,'phone_calls':0,'physical_case_pass':False,
            'automatic_retry':False}
        final=put(out+'/RESULT.json',encoded(result))
        print(encoded({'result':final,**result}).decode(),end='');return 0
    except BaseException as error:
        if not written:
            written=True
            try:write_retained(out,c.retained)
            except BaseException:pass
        put(out+'/FAILURE.json',encoded({'state':'INCOMPLETE_ORIGINAL_CAPTURE_NO_RETRY',
            'error_type':type(error).__name__,'error':str(error)[:1024],'physical_case_pass':False,
            'automatic_retry':False,'phone_calls':0}))
        raise

if __name__=='__main__':raise SystemExit(main())
'''
raw=header+'\n\n'.join(parts)+'\n'+tail
compile(raw,'capture_fault_p4.py','exec')
(R/'source/capture_fault_p4.py').write_text(raw)
print({'bytes':len(raw.encode()),'sha256':hashlib.sha256(raw.encode()).hexdigest(),
       'exact_reused_definitions':len(names),'phone_calls':0})
