#!/usr/bin/env python3
"""Fixed local original-byte verification. No remote or retained-source execution."""
import ast
import base64
import hashlib
import io
import json
import lzma
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import stat
import tarfile
import zlib

HERE = Path(__file__).resolve().parent
OUT = HERE.parent
WORK = OUT.parent
REMOTE = '/home/alex/razr60-local-model-v150/fixed19-root-1ad3-epoch-retained-footprint-read02/FULL-ORIGINALS.tar.xz'
VERSION = '66306:44336387:4531388:1793897324452756243:1793897324452756243'
ARCHIVE_PIN = (4531388, 'd5982a434a6317ddf7b2503127d1581b0aa55d828096ed42e1a7b276af8f21ed')
MANIFEST_PIN = (2436, 'f72805b724317aa4a8a60389e217cfc1c4f9aa6c54900bc8603c25d481da7251')
TAR_PIN = (12083200, '713258173719a40d998ffdb6b5a4b632f5c0e68a880e1595933f9485dbd0d1c2')
SOURCE_PIN = (58657, '779546dde4ed021be8851c0c1410dfdabc7019533986530e78bd58e3924aaf34')
FOOTPRINT_PIN = (176976, '6bb6a8466bd8bcb2d7bb2aa6e376113d481dab27ca919a5f419fa19c07d0d40f')
LABEL = 'ng-epoch-retained-footprint-1ad3-read02'
BOOT = 'f8019f83-20a7-4f18-bea1-51c980621e4d'
RELEASE = WORK/'epoch_footprint_observer_candidate02/delivery-final01/package'

def need(value, message):
    if not value:
        raise ValueError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def desc(raw):
    return {'bytes': len(raw), 'sha256': sha(raw)}

def pin(raw, expected, name):
    need((len(raw), sha(raw)) == expected, name)
    return raw

def descriptor(path, raw=None):
    raw = path.read_bytes() if raw is None else raw
    return {'path': str(path), **desc(raw)}

def strict(raw):
    def pairs(values):
        out = {}
        for key, value in values:
            need(key not in out, 'duplicate JSON key')
            out[key] = value
        return out
    def invalid(value):
        raise ValueError('nonfinite JSON value: '+value)
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)

def enc(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')

def same(left, right, name):
    need(enc(left) == enc(right), name)

def write_new(path, raw):
    with path.open('xb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())

def write_json(path, value):
    write_new(path, (json.dumps(value, sort_keys=True, ensure_ascii=False, indent=2, allow_nan=False)+'\n').encode('utf-8'))

def b64(value):
    need(type(value) is str, 'base64 string')
    raw = base64.b64decode(value, validate=True)
    need(base64.b64encode(raw).decode('ascii') == value, 'canonical base64')
    return raw

def full9(value):
    need(type(value) is list and len(value) == 9 and all(type(x) is int for x in value), 'exact full9 integer vector')

def safe_path(value):
    need(type(value) is str, 'literal path')
    p = PurePosixPath(value)
    need(p.is_absolute() and str(p) == value and '..' not in p.parts and len(p.parts) <= 64, 'canonical absolute path')
    return p

def unique_rows(rows):
    need(type(rows) is list, 'row list')
    out = {}
    for row in rows:
        safe_path(row['path']); need(row['path'] not in out, 'duplicate original path')
        out[row['path']] = row
    return out

def time_interval(row):
    a, z = row['started_monotonic_ns'], row['finished_monotonic_ns']
    need(type(a) is int and type(z) is int and 0 < a <= z, 'actual monotonic interval')
    return a, z

def reconstruct():
    manifest_path = OUT/'ARCHIVE-MANIFEST.json'
    manifest_raw = pin(manifest_path.read_bytes(), MANIFEST_PIN, 'original archive manifest pin')
    manifest = strict(manifest_raw)
    same(manifest['archive'], {'path': REMOTE, 'bytes': ARCHIVE_PIN[0], 'sha256': ARCHIVE_PIN[1]}, 'archive descriptor')
    same(manifest['tar'], {'bytes': TAR_PIN[0], 'sha256': TAR_PIN[1]}, 'tar descriptor')
    need(manifest['case_pass'] is False and manifest['originals_changed'] is False, 'original manifest scope')
    expected = {row['path']: row for row in manifest['files']}
    need(len(expected) == len(manifest['files']) == 12, 'exact twelve original members')
    offsets = list(range(0, ARCHIVE_PIN[0], 65536))
    need(len(offsets) == 70, 'fixed seventy chunks')
    end_record = strict((HERE/'DOWNLOAD-END02.json').read_bytes())
    need(end_record['completed'] is True and end_record['verified_chunks'] == 70 and end_record['retry'] is False, 'complete non-retried download')
    reconciliation = strict((HERE/'LOCAL-YIELD-RECONCILIATION.json').read_bytes())
    need(reconciliation['state'] == 'SAME_LOCAL_VERIFIER_JOINED_ZERO_NO_REMOTE_RETRY'
         and reconciliation['remote_rereads'] == 0
         and reconciliation['final_local_join_result']['exit_code'] == 0,
         'same original local verification process was reconciled without a remote reread')
    chunks, records = [], []
    for offset in offsets:
        stem = 'chunk-%08d' % offset
        tool_path = OUT/'CONTROLLER-ARCHIVE-FIRST01.raw-tool.json' if offset == 0 else HERE/(stem+'.raw-tool.json')
        tool_raw = tool_path.read_bytes(); tool = strict(tool_raw)
        need(tool.get('isError') is False and len(tool['content']) == 1 and tool['content'][0]['type'] == 'text', 'successful original tool result')
        value = strict(tool['content'][0]['text']); raw = b64(value['data_base64'])
        last = min(offset+65536, ARCHIVE_PIN[0])
        need(value['path'] == REMOTE and value['version'] == VERSION and value['size'] == ARCHIVE_PIN[0], 'same fixed-version file')
        need(type(value['offset']) is int and value['offset'] == offset and type(value['next_offset']) is int and value['next_offset'] == last, 'chunk offsets')
        need(type(value['eof']) is bool and value['eof'] == (last == ARCHIVE_PIN[0]), 'final exact EOF')
        need(len(raw) == last-offset and sha(raw) == value['chunk_sha256'], 'independent chunk bytes and SHA')
        chunk_path = HERE/(stem+'.bin'); need(chunk_path.read_bytes() == raw, 'retained chunk exact bytes')
        row = {'offset': offset, 'next_offset': last, 'eof': value['eof'], 'chunk': descriptor(chunk_path, raw),
               'tool_receipt': descriptor(tool_path, tool_raw), 'source_version': VERSION, 'first_chunk_reused': offset == 0}
        if offset:
            request_path = HERE/(stem+'.request.json')
            same(strict(request_path.read_bytes()), {'host':'pocket4', 'path':REMOTE, 'offset':offset,
                 'limit':65536, 'expected_version':VERSION}, 'exact authorized request')
            row['request'] = descriptor(request_path)
            need((HERE/(stem+'.tool-text.original')).read_bytes() == tool['content'][0]['text'].encode('utf-8'), 'original unmodified tool text')
        records.append(row); chunks.append(raw)
    archive = pin(b''.join(chunks), ARCHIVE_PIN, 'complete XZ archive')
    decoder = lzma.LZMADecompressor(format=lzma.FORMAT_XZ, memlimit=128*1024*1024)
    tar = decoder.decompress(archive, max_length=TAR_PIN[0]+1)
    need(decoder.eof and not decoder.unused_data, 'one complete checksum-verified XZ stream')
    pin(tar, TAR_PIN, 'complete uncompressed tar')
    bodies = {}
    with tarfile.open(fileobj=io.BytesIO(tar), mode='r:') as tf:
        members = tf.getmembers()
        need(len(members) == 12 and len({m.name for m in members}) == 12 and {m.name for m in members} == set(expected), 'exact twelve-member closed set')
        for member in members:
            p = PurePosixPath(member.name)
            need(member.isfile() and not member.issym() and not member.islnk() and p.name == member.name and not p.is_absolute() and '..' not in p.parts, 'flat regular safe member')
            row = expected[member.name]; need(member.size == row['bytes'], 'tar member header size')
            with tf.extractfile(member) as stream:
                body = stream.read(row['bytes']+1)
            pin(body, (row['bytes'], row['sha256']), 'complete original '+member.name)
            bodies[member.name] = body
    archive_path = OUT/'FULL-ORIGINALS.tar.xz'; write_new(archive_path, archive)
    extracted = OUT/'extracted'; extracted.mkdir(mode=0o700)
    originals = []
    for name in sorted(bodies):
        path = extracted/name; write_new(path, bodies[name])
        need(path.read_bytes() == bodies[name], 'local original readback')
        originals.append(descriptor(path, bodies[name]))
    report = {'schema':'hepta.fixed19.originals-download-verification.v1',
        'state':'COMPLETE_PINNED_VERSION_ARCHIVE_AND_TWELVE_ORIGINALS_VERIFIED',
        'manifest':descriptor(manifest_path,manifest_raw), 'archive':descriptor(archive_path,archive),
        'uncompressed_tar':desc(tar), 'source_version':VERSION, 'chunks':records, 'chunk_count':70,
        'exact_member_count':12, 'originals':originals, 'all_member_bytes_sha256_verified':True,
        'xz_stream_complete_and_checksum_verified':True, 'source_changed':False,
        'first_chunk_remotely_repeated':False, 'other_remote_paths_read':False,
        'initial_local_nonterminal_stop_preserved':descriptor(HERE/'DOWNLOAD-END.json'),
        'local_verifier_yield_reconciliation':descriptor(HERE/'LOCAL-YIELD-RECONCILIATION.json'),
        'complete_download_record':descriptor(HERE/'DOWNLOAD-END02.json'),
        'observer_reexecuted':False, 'phone_operations':0, 'process_starts':0, 'case_pass':False,
        'download_does_not_change_observation_time_or_create_atomic_snapshot':True,
        'verifier_source':descriptor(Path(__file__))}
    write_json(OUT/'LOCAL-ARCHIVE-COMPLETE-VERIFICATION.json',report)
    return bodies

def verify_observation(bodies):
    source = pin(bodies['PROBE-SOURCE.original.py'], SOURCE_PIN, 'actual exact observer source')
    need(source == (RELEASE/'source/observe_fixed_epoch_footprint_once.py').read_bytes(), 'frozen observer source')
    request = strict(bodies['REQUEST.original.json']); intent = strict(bodies['INTENT.json'])
    caller = (RELEASE/'operator/P4-LAUNCHER.py').read_text()
    assignments = {n.targets[0].id:n.value for n in ast.parse(caller).body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
    literal_probe = ast.literal_eval(assignments['PROBE'])
    need(type(literal_probe) is bytes and literal_probe == source, 'caller exact PROBE bytes literal')
    same(request, ast.literal_eval(assignments['REQ']), 'actual request vs frozen caller literal')
    need(intent['probe_source_sha256'] == SOURCE_PIN[1] and intent['request_sha256'] == sha(bodies['REQUEST.original.json']), 'P4 original intent source/request')
    child, joined = (strict(bodies[k]) for k in ('CHILD.json','JOINED.json'))
    need(type(child['pid']) is int and child['pid'] > 1 and joined['pid'] == child['pid'] and joined['returncode'] == 0 and joined['wait_returned'] is True and joined['signals_sent'] == 0, 'owned original actor joined')
    phone_intent = strict(bodies['phone-intent.json.original']); phone_result = strict(bodies['phone-result.json.original'])
    same(phone_intent['request'], request, '179a exact original request')
    need(phone_intent['label'] == phone_result['label'] == LABEL and phone_intent['request_sha256'] == sha(bodies['REQUEST.original.json']) and phone_intent['automatic_replay'] is False, '179a identity and once request')
    need(phone_result['status'] == 'command_exited' and phone_result['phone']['rc'] == 0 and phone_result['phone']['stderr'] == '', 'complete successful original phone observer')
    need(phone_result['phone']['command'] == '/debug_ramdisk/su -c '+shlex.quote(request['command']), 'exact su wrapper command')
    stdout = bodies['PHONE-STDOUT.original']
    need(phone_result['phone']['stdout'].encode('utf-8') == stdout, 'whole phone stdout raw link')
    result = strict(bodies['RESULT.json'])
    need(result['actor_returncode'] == result['phone_returncode'] == 0 and result['source_sha256'] == SOURCE_PIN[1] and result['case_pass'] is False, 'actual P4 observer result')
    need({k:result['phone_stdout'][k] for k in ('bytes','sha256')} == desc(stdout), 'P4 whole stdout descriptor')
    baseline = strict(bodies['phone-baseline.json.original'])
    need(baseline['rc'] == 0 and baseline['stdout'].splitlines()[0] == BOOT, 'original actor baseline boot')
    report = strict(stdout)
    need(report['schema'] == 'hepta.native-guard.fixed-epoch-retained-footprint-observation.v2' and report['state'] == 'EXACT_FIXED_RETAINED_ORIGINALS_AND_CURRENT_ABSENCES_OBSERVED' and report['observation_complete'] is True and report['failure'] is None and report['complete_raw_observation_retained'] is True, 'actual complete v2 observation')
    need(report['boot_id'] == BOOT and report['whole_file_reads'] == 252 and report['present_rows_observed'] == 146 and report['full_file_bodies_retained'] == 126 and report['raw_file_bytes_retained'] == 7114062, 'fixed scope counts')
    for name in ('hard_preemptive_deadline_claimed','atomic_global_snapshot_claimed','global_clearance_proof','epoch_initialized','future_input_authorization','native_case_qualified','case_pass','new_nonce_or_lease','automatic_retry'):
        need(report[name] is False, 'non-authorization flag '+name)
    for name in ('runtime_modules_loaded','runtime_function_calls','process_launches','phone_content_writes','endpoint_connections','signals','locks_acquired','model_requests','native_sends','boundary_publications'):
        need(type(report[name]) is int and report[name] == 0, 'zero operation '+name)
    need(report['owned_read_fd_observation']['complete'] is True and report['owned_read_fd_observation']['new_read_FDs_remaining'] == [], 'actual owned FD cleanup')
    same(report['limits'], {'cooperative_seconds':30,'physical_read_bytes':16*1024*1024,'object_operations':4096,'directory_names':20000,'metadata_bytes':512*1024,'packet_raw_bytes':16*1024*1024,'phone_report_bytes':8*1024*1024}, 'unchanged full bounds')
    need(0 <= report['total_wall_seconds'] < 30 and 2*7114062 <= report['physical_read_bytes_charged'] <= 16*1024*1024 and 0 < report['object_operations'] <= 4096 and len(stdout) <= 8*1024*1024, 'actual complete shared budgets')
    packet = report['observations']; need(type(packet) is dict and set(packet) == {'codec','packed','raw','data'} and packet['codec'] == 'zlib+base64', 'exact packet')
    for key in ('packed','raw'):
        d = packet[key]
        need(type(d) is dict and set(d) == {'bytes','sha256'} and type(d['bytes']) is int and 0 < d['bytes'] <= 16*1024*1024 and re.fullmatch('[0-9a-f]{64}',d['sha256']), 'bounded packet descriptor')
    packed = b64(packet['data']); same(desc(packed),packet['packed'],'complete packed observation')
    decoder = zlib.decompressobj(); raw = decoder.decompress(packed,packet['raw']['bytes']+1)
    need(decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail and decoder.flush() == b'', 'one bounded complete observation zlib stream')
    same(desc(raw),packet['raw'],'whole lossless observation'); observations = strict(raw)
    need(enc(observations) == raw, 'exact canonical observation bytes')
    footprint_path = WORK/'epoch_native_candidate01/footprint01/FOOTPRINT.json'
    footprint_raw = pin(footprint_path.read_bytes(),FOOTPRINT_PIN,'fixed historical footprint')
    footprint = strict(footprint_raw); same(report['footprint_original'],desc(footprint_raw),'actual observed fixed request')
    entries = unique_rows(observations['entries']); files = unique_rows(observations['file_originals'])
    wanted = {r['path']:r for r in footprint['retained_directory_member_originals']+footprint['fixed_control_leaves']}
    need(set(entries) == set(wanted) and len(entries) == 146 and len(files) == 126, 'exact present original scope')
    tree_paths = {r['path'] for r in footprint['retained_directory_member_originals']}
    body_sum = 0
    for path,row in entries.items():
        expected = wanted[path]; full9(row['metadata'])
        need(row['kind'] in ('file','directory') and row['scope'] == ('retained_tree' if path in tree_paths else 'fixed_control_leaf'), 'actual present kind/scope')
        metadata_expected = expected.get('metadata',expected.get('historical_metadata'))
        if metadata_expected is not None: same(row['metadata'],metadata_expected,'fixed historical full9')
        if expected.get('selinux_raw_hex') is not None: need(row['selinux_raw_hex'] == expected['selinux_raw_hex'],'fixed actual label')
        need(type(row['selinux_raw_hex']) is str and len(bytes.fromhex(row['selinux_raw_hex'])) in range(1,4097), 'complete SELinux raw label')
        if row['kind'] == 'directory':
            need(path not in files and stat.S_ISDIR(row['metadata'][2]), 'directory type')
            same(row['names'],expected['names'],'complete original directory names')
        else:
            need(path in files and stat.S_ISREG(row['metadata'][2]) and row['metadata'][5] == 1, 'regular single-link original')
            item = files[path]; need(item['encoding'] == 'base64','original byte encoding'); body = b64(item['data_base64'])
            same(desc(body),{k:item[k] for k in ('bytes','sha256')},'complete retained file body')
            same(desc(body),{k:row[k] for k in ('bytes','sha256')},'retained body vs actual file observation')
            need(len(body) == row['metadata'][6] == expected.get('bytes',expected.get('expected_bytes')) and sha(body) == expected.get('sha256',expected.get('expected_sha256')), 'fixed requested body')
            body_sum += len(body)
        books = observations['read_bookends'][path]
        a,z = time_interval(books['first']); b,y = time_interval(books['final'])
        need(z <= b and books['both_reads_are_whole_bodies'] is (row['kind']=='file'), 'two real whole-read bookends')
    need(set(observations['read_bookends']) == set(entries) and body_sum == 7114062, 'complete read-bookend and byte accounting')
    parents = observations['immediate_parent_observations']; parent_map = unique_rows(parents)
    for parent in parents:
        full9(parent['metadata']); need(stat.S_ISDIR(parent['metadata'][2]), 'actual parent directory')
        names = parent['names']; need(type(names) is list and names == sorted(set(names)) and len(names) <= 20000 and all(type(n) is str and n not in ('','.','..') and '/' not in n and '\0' not in n for n in names), 'complete actual parent names')
    expected_absences = {row['path'] for row in footprint['absence_checks']+footprint['new_control_roots']}
    absences = unique_rows(observations['positive_absence_observations'])
    need(set(absences) == expected_absences and len(absences) == 65, 'exact sixty-five fixed absences')
    expanded = []
    for path,row in absences.items():
        need(row['state'] == 'POSITIVELY_OBSERVED_ENOENT' and row['absence_is_new_permission'] is False, 'positive non-authorizing absence')
        for side in ('first','final'):
            observed = row[side]; time_interval(observed)
            need(type(observed['held_parent_enoent_observations']) is int and observed['held_parent_enoent_observations'] == 2 and type(observed['reopened_parent_enoent_observations']) is int and observed['reopened_parent_enoent_observations'] == 1, 'actual held and reopened ENOENT counts')
            ref = observed['canonical_parent_observation']
            need(type(ref) is dict and set(ref) == {'table','index','serialized_observation'} and ref['table'] == 'immediate_parent_observations' and type(ref['index']) is int and 0 <= ref['index'] < len(parents), 'exact v2 serialized-observation reference')
            parent = parents[ref['index']]; same(ref['serialized_observation'],desc(enc(parent)),'complete referenced observation bytes')
            need(parent['path'] == str(PurePosixPath(path).parent) and PurePosixPath(path).name not in parent['names'], 'actual referenced parent and absent name')
            expanded.append({'path':path,'round':side,'index':ref['index'],'parent_path':parent['path'],'serialized_observation':desc(enc(parent))})
        same(row['first']['canonical_parent_observation'],row['final']['canonical_parent_observation'],'same complete first/final parent observation')
        need(row['first']['finished_monotonic_ns'] <= row['final']['started_monotonic_ns'],'absence observation order')
    aliases = observations['actual_alias_checks']; need(len(aliases) == 2,'two extra actual aliases')
    for pair,proof in zip(footprint['extra_alias_pairs'],aliases):
        same(proof['paths'],pair,'exact failed-root alias pair')
        left,right=(entries[path] for path in pair)
        need(left['kind'] == right['kind'] == 'directory' and left['names'] == right['names'] == [],'two empty executor aliases')
        for key in ('metadata','names','selinux_raw_hex'): same(left[key],right[key],'actual alias '+key); same(proof[key],left[key],'alias proof '+key)
        need(proof['both_views_observed_and_charged'] is True,'both alias views charged')
    bridge=observations['fixed_proc_root_bridge']; same(bridge['first']['identity'],bridge['final']['identity'],'stable actual proc-root bridge')
    for side in ('first','final'):
        item=bridge[side]['pid1_stat_original']; stat_raw=b64(item['data_base64'])
        same(desc(stat_raw),{k:item[k] for k in ('bytes','sha256')},'whole actual PID1 stat raw')
        text=stat_raw.decode('ascii'); end=text.rfind(')'); fields=text[end+2:].split(); generation=[int(text.split('(',1)[0]),int(fields[2]),int(fields[3]),int(fields[19])]
        same(generation,bridge[side]['identity']['pid1_generation'],'actual parsed PID1 generation')
        need(generation[0] == 1 and generation[3] == 0,'fixed native init generation')
        for name in ('followed_android_root','gnu_root'): full9(bridge[side]['identity'][name]['metadata'])
        boot=observations['boot_originals'][side]; boot_raw=b64(boot['data_base64']); same(desc(boot_raw),{k:boot[k] for k in ('bytes','sha256')},'whole boot raw'); need(boot_raw == (BOOT+'\n').encode(),'unchanged actual boot')
    meta=dict(observations); meta['file_originals']=[{**row,'data_base64':''} for row in observations['file_originals']]
    metadata_bytes=len(enc(meta)); need(metadata_bytes <= 512*1024,'complete metadata within unchanged512KiB')
    write_new(OUT/'OBSERVATIONS.decoded-original.json',raw)
    proof={'schema':'hepta.fixed19.fixed-footprint-local-original-verification.v1',
        'state':'COMPLETE_TWELVE_ORIGINALS_AND_LOSSLESS_V2_OBSERVATION_VERIFIED',
        'phone_stdout':descriptor(OUT/'extracted/PHONE-STDOUT.original',stdout),
        'observations':descriptor(OUT/'OBSERVATIONS.decoded-original.json',raw),
        'observer_source':desc(source),'footprint_original':descriptor(footprint_path,footprint_raw),
        'actual_present_rows':146,'complete_file_bodies':126,'complete_raw_file_bytes':body_sum,
        'whole_physical_file_reads':252,'physical_read_bytes_charged':report['physical_read_bytes_charged'],
        'complete_parent_table_rows':len(parents),'canonical_ancestor_rows':len(observations['canonical_ancestor_observations']),
        'positive_absences':65,'expanded_v2_parent_references':expanded,'all130_references_exact':len(expanded)==130,
        'complete_metadata_bytes':metadata_bytes,'unchanged_metadata_limit':512*1024,
        'actual_extra_alias_pairs':aliases,'actual_proc_root_bridge':bridge['first']['identity'],
        'actual_total_wall_seconds':report['total_wall_seconds'],
        'owned_fds_complete':True,'historical_inputs_not_relabelled_fresh':True,
        'observations_preserved_whole_bytes':True,'target_source_executed_by_local_verifier':False,
        'download_created_new_observation':False,'global_clearance_proof':False,
        'epoch_initialized':False,'future_nonce_or_lease_authorized':False,'case_pass':False,
        'verifier_source':descriptor(Path(__file__))}
    write_json(OUT/'LOCAL-OBSERVATION-VERIFICATION.json',proof)
    print(json.dumps({'state':proof['state'],'phone_stdout':proof['phone_stdout'],'observations':proof['observations'],
        'metadata_bytes':metadata_bytes,'wall_seconds':report['total_wall_seconds'],
        'report':descriptor(OUT/'LOCAL-OBSERVATION-VERIFICATION.json')},ensure_ascii=False))

if __name__ == '__main__':
    verify_observation(reconstruct())
