"""Verify one fixed-version binary-read result; never performs remote I/O."""
import base64
import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent

def write_once(path, raw):
    with path.open('xb') as out:
        out.write(raw)

def main():
    offset = int(sys.argv[1])
    prefix = HERE / ('chunk-%08d' % offset)
    expected = json.loads((HERE / 'EXPECTED.json').read_bytes())
    response_raw = prefix.with_suffix('.raw-tool.json').read_bytes()
    response = json.loads(response_raw)
    assert isinstance(response, dict) and not response.get('isError'), 'tool rejected/error'
    content = response.get('content')
    assert isinstance(content, list) and len(content) == 1 and content[0].get('type') == 'text', 'tool result shape'
    original_tool_text = content[0]['text']
    write_once(prefix.with_suffix('.tool-text.original'), original_tool_text.encode('utf-8'))
    value = json.loads(original_tool_text)
    assert value['path'] == expected['path'], 'path'
    assert type(value['offset']) is int and value['offset'] == offset, 'offset'
    assert value['version'] == expected['version'], 'version'
    assert type(value['size']) is int and value['size'] == expected['size'], 'size'
    raw = base64.b64decode(value['data_base64'], validate=True)
    assert base64.b64encode(raw).decode('ascii') == value['data_base64'], 'canonical base64'
    length = min(expected['chunk_limit'], expected['size'] - offset)
    assert 0 < length <= 65536 and len(raw) == length, 'chunk length'
    assert type(value['next_offset']) is int and value['next_offset'] == offset + length, 'next offset'
    assert type(value['eof']) is bool and value['eof'] == (offset + length == expected['size']), 'eof'
    digest = hashlib.sha256(raw).hexdigest()
    assert value['chunk_sha256'] == digest, 'chunk sha256'
    write_once(prefix.with_suffix('.bin'), raw)
    proof = {'offset': offset, 'bytes': len(raw), 'sha256': digest, 'version': value['version'],
             'eof': value['eof'], 'next_offset': value['next_offset'], 'remote_repeated': False,
             'tool_original': prefix.with_suffix('.raw-tool.json').name,
             'tool_original_bytes': len(response_raw), 'tool_original_sha256': hashlib.sha256(response_raw).hexdigest(),
             'tool_text_bytes': len(original_tool_text.encode('utf-8')),
             'tool_text_sha256': hashlib.sha256(original_tool_text.encode('utf-8')).hexdigest()}
    write_once(prefix.with_suffix('.verified.json'), (json.dumps(proof, sort_keys=True, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'offset': offset, 'bytes': len(raw), 'eof': value['eof'], 'verified': True}))

if __name__ == '__main__':
    main()
